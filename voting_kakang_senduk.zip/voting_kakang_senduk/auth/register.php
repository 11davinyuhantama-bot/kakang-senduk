
<?php
session_start();
require_once '../config/koneksi.php';

if (isset($_SESSION['id'])) {
    header("Location: ../index.php");
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $nama = trim($_POST['nama'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $no_hp = trim($_POST['no_hp'] ?? '');
    $password = $_POST['password'] ?? '';
    $konfirmasi = $_POST['konfirmasi'] ?? '';

    if ($nama === '' || $email === '' || $no_hp === '') {
        $error = "Semua data wajib diisi!";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Format email tidak valid!";
    } elseif (strlen($password) < 8) {
        $error = "Password minimal 8 karakter!";
    } elseif ($password !== $konfirmasi) {
        $error = "Konfirmasi password tidak cocok!";
    } else {

        $cek = mysqli_prepare($conn,
            "SELECT id FROM users WHERE email = ?");

        mysqli_stmt_bind_param($cek, "s", $email);
        mysqli_stmt_execute($cek);

        $hasil = mysqli_stmt_get_result($cek);

        if (mysqli_num_rows($hasil) > 0) {

            $error = "Email sudah terdaftar!";

        } else {

            $hash = password_hash(
                $password,
                PASSWORD_DEFAULT
            );

            $role = 'pemilih';

            $stmt = mysqli_prepare($conn,
                "INSERT INTO users
                (nama,email,no_hp,password,role)
                VALUES (?,?,?,?,?)");

            mysqli_stmt_bind_param(
                $stmt,
                "sssss",
                $nama,
                $email,
                $no_hp,
                $hash,
                $role
            );

            if (mysqli_stmt_execute($stmt)) {
                header("Location: login.php?daftar=berhasil");
                exit;
            } else {
                $error = "Registrasi gagal. Silakan coba kembali.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Register | Kakang Senduk Ponorogo</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<style>

body {
    min-height: 100vh;
    background: linear-gradient(rgba(20, 8, 10, .58), rgba(20, 8, 10, .72)),
                url('../assets/img/bg-nusantara.jpg') center / cover fixed;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Segoe UI',sans-serif;
    padding: 30px 0;
}

.register-card {
    background: white;
    width: 100%;
    max-width: 500px;
    padding: 35px;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0,0,0,.25);
}

.logo {
    width: 70px;
    height: 70px;
    background: #681d25;
    color: #e9b94e;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 27px;
    font-weight: bold;
    margin: auto;
}

.title {
    color: #681d25;
    font-weight: 800;
}

.form-control {
    padding: 11px;
    border-radius: 10px;
}

.btn-register {
    background: #681d25;
    color: white;
    padding: 12px;
    border-radius: 10px;
    font-weight: bold;
}

.btn-register:hover {
    background: #8c2633;
    color: white;
}

</style>

</head>

<body>

<div class="container px-3">

<div class="register-card mx-auto">

<div class="text-center mb-4">

<div class="logo">KS</div>

<h3 class="title mt-3">KAKANG SENDUK</h3>

<p class="text-muted">
Buat Akun Pemilih
</p>

</div>

<?php if ($error): ?>
<div class="alert alert-danger">
<?= htmlspecialchars($error) ?>
</div>
<?php endif; ?>

<form method="POST">

<div class="mb-3">
<label class="form-label fw-semibold">
Nama Lengkap
</label>

<input type="text"
name="nama"
class="form-control"
placeholder="Masukkan nama lengkap"
value="<?= htmlspecialchars($_POST['nama'] ?? '') ?>"
required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">
Email
</label>

<input type="email"
name="email"
class="form-control"
placeholder="contoh@email.com"
value="<?= htmlspecialchars($_POST['email'] ?? '') ?>"
required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">
Nomor HP
</label>

<input type="tel"
name="no_hp"
class="form-control"
placeholder="08xxxxxxxxxx"
value="<?= htmlspecialchars($_POST['no_hp'] ?? '') ?>"
required>
</div>

<div class="mb-3">
<label class="form-label fw-semibold">
Password
</label>

<input type="password"
name="password"
class="form-control"
placeholder="Minimal 8 karakter"
minlength="8"
required>
</div>

<div class="mb-4">
<label class="form-label fw-semibold">
Konfirmasi Password
</label>

<input type="password"
name="konfirmasi"
class="form-control"
placeholder="Ulangi password"
minlength="8"
required>
</div>

<div class="form-check mb-4">
<input class="form-check-input"
type="checkbox"
id="setuju"
required>

<label class="form-check-label small" for="setuju">
Saya menyetujui ketentuan pemilihan dan aturan voting.
</label>
</div>

<button type="submit"
class="btn btn-register w-100">
Daftar Sekarang
</button>

</form>

<div class="text-center mt-4">

<p class="text-muted">
Sudah memiliki akun?
<a href="login.php"
class="fw-bold text-decoration-none"
style="color:#8c2633">
Login Sekarang
</a>
</p>

<a href="../index.php"
class="text-muted text-decoration-none">
← Kembali ke Beranda
</a>

</div>

</div>
</div>

</body>
</html>
