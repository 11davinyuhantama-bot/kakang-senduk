
<?php
session_start();
require_once '../config/koneksi.php';

if (isset($_SESSION['id'])) {
    if ($_SESSION['role'] === 'admin') {
        header("Location: ../admin/dashboard.php");
    } elseif (($_GET['redirect'] ?? '') === 'voting') {
        header("Location: ../pages/voting.php");
    } else {
        header("Location: ../index.php");
    }
    exit;
}

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = mysqli_prepare($conn,
        "SELECT id, nama, email, password, role
         FROM users WHERE email = ?");

    mysqli_stmt_bind_param($stmt, "s", $email);
    mysqli_stmt_execute($stmt);

    $result = mysqli_stmt_get_result($stmt);
    $user = mysqli_fetch_assoc($result);

    if ($user && password_verify($password, $user['password'])) {

        session_regenerate_id(true);

        $_SESSION['id'] = $user['id'];
        $_SESSION['nama'] = $user['nama'];
        $_SESSION['email'] = $user['email'];
        $_SESSION['role'] = $user['role'];

        if ($user['role'] === 'admin') {
            header("Location: ../admin/dashboard.php");
        } elseif (($_GET['redirect'] ?? '') === 'voting') {
            header("Location: ../pages/voting.php");
        } else {
            header("Location: ../index.php");
        }
        exit;

    } else {
        $error = "Email atau password yang Anda masukkan salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<title>Login | Kakang Senduk Ponorogo</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet" href="../assets/css/style.css">

<style>
body {
    min-height: 100vh;
    background: linear-gradient(rgba(20, 8, 10, .58), rgba(20, 8, 10, .72)),
                url('../assets/img/bg-nusantara.jpg') center / cover fixed;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: 'Segoe UI',sans-serif;
}

.login-card {
    background: white;
    width: 100%;
    max-width: 430px;
    padding: 40px;
    border-radius: 20px;
    box-shadow: 0 15px 40px rgba(0,0,0,.25);
}

.logo {
    width: 75px;
    height: 75px;
    background: #681d25;
    color: #e9b94e;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    font-weight: bold;
    margin: auto;
}

.title {
    color: #681d25;
    font-weight: 800;
}

.form-control {
    padding: 12px;
    border-radius: 10px;
}

.btn-login {
    background: #681d25;
    color: white;
    padding: 12px;
    border-radius: 10px;
    font-weight: bold;
}

.btn-login:hover {
    background: #8c2633;
    color: white;
}
</style>
</head>

<body>

<div class="container px-3">

<div class="login-card mx-auto">

<div class="text-center mb-4">

<div class="logo">KS</div>

<h3 class="title mt-3">KAKANG SENDUK</h3>

<p class="text-muted">
Ponorogo Tourism Ambassador
</p>

<h5 class="fw-bold mt-4">Selamat Datang!</h5>

<p class="text-muted small">
Silakan login untuk memberikan suara.
</p>

</div>

<?php if ($error): ?>
<div class="alert alert-danger">
<?= htmlspecialchars($error) ?>
</div>
<?php endif; ?>

<?php if (isset($_GET['daftar'])): ?>
<div class="alert alert-success">
Registrasi berhasil! Silakan login.
</div>
<?php endif; ?>

<form method="POST">

<div class="mb-3">
<label class="form-label fw-semibold">Email</label>
<input type="email" name="email"
class="form-control"
placeholder="Masukkan email"
autocomplete="email"
required>
</div>

<div class="mb-4">
<label class="form-label fw-semibold">Password</label>
<input type="password" name="password"
class="form-control"
placeholder="Masukkan password"
autocomplete="current-password"
required>
</div>

<button type="submit"
class="btn btn-login w-100">
Login Sekarang
</button>

</form>

<div class="text-center mt-4">

<p class="text-muted mb-2">
Belum memiliki akun?
</p>

<a href="register.php"
class="fw-bold text-decoration-none"
style="color:#8c2633">
Daftar Sekarang
</a>

<hr>

<a href="../index.php"
class="text-muted text-decoration-none">
← Kembali ke Beranda
</a>

</div>

</div>
</div>

</body>
</html>
