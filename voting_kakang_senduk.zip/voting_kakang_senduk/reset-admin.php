
<?php
require_once 'config/koneksi.php';

$nama = "Administrator";
$email = "admin@kakangsenduk.com";
$no_hp = "081234567890";
$password = password_hash("admin123", PASSWORD_DEFAULT);
$role = "admin";

$stmt = mysqli_prepare($conn,
    "SELECT id FROM users WHERE email = ?");

mysqli_stmt_bind_param($stmt, "s", $email);
mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) > 0) {

    $stmt = mysqli_prepare($conn,
        "UPDATE users SET password = ?, role = 'admin'
         WHERE email = ?");

    mysqli_stmt_bind_param($stmt, "ss", $password, $email);

} else {

    $stmt = mysqli_prepare($conn,
        "INSERT INTO users
        (nama,email,no_hp,password,role)
        VALUES (?,?,?,?,?)");

    mysqli_stmt_bind_param(
        $stmt, "sssss",
        $nama, $email, $no_hp, $password, $role
    );
}

if (mysqli_stmt_execute($stmt)) {
    echo "Admin berhasil dibuat atau diperbarui!";
} else {
    echo "Gagal: " . mysqli_error($conn);
}
?>
