<?php
require_once __DIR__ . '/_common.php';
if (!pemilihLogin()) {
    if (isset($_SESSION['id']) && $_SESSION['role'] === 'admin') {
        header('Location: ../admin/dashboard.php');
    } else {
        header('Location: ../auth/login.php?redirect=voting');
    }
    exit;
}
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$flash = '';
$jenisFlash = 'success';
$periode = periodeAktif($conn);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        $flash = 'Permintaan tidak valid. Muat ulang halaman dan coba kembali.';
        $jenisFlash = 'danger';
    } elseif (!$periode) {
        $flash = 'Voting belum dibuka atau periode pemilihan sudah berakhir.';
        $jenisFlash = 'warning';
    } else {
        $kontestanId = filter_input(INPUT_POST, 'kontestan_id', FILTER_VALIDATE_INT);
        $stmt = $conn->prepare('SELECT id, nama, kategori FROM kontestan WHERE id = ?');
        $stmt->bind_param('i', $kontestanId);
        $stmt->execute();
        $peserta = $stmt->get_result()->fetch_assoc();
        if (!$peserta || !in_array($peserta['kategori'], ['Kakang', 'Senduk'], true)) {
            $flash = 'Kontestan yang dipilih tidak valid.';
            $jenisFlash = 'danger';
        } else {
            try {
                $stmt = $conn->prepare('INSERT INTO voting (user_id, kontestan_id, kategori) VALUES (?, ?, ?)');
                $userId = (int)$_SESSION['id'];
                $stmt->bind_param('iis', $userId, $kontestanId, $peserta['kategori']);
                $stmt->execute();
                $flash = 'Suara Anda untuk ' . $peserta['nama'] . ' (' . $peserta['kategori'] . ') berhasil tercatat.';
            } catch (mysqli_sql_exception $e) {
                if ((int)$e->getCode() === 1062) {
                    $flash = 'Anda sudah memberikan suara untuk kategori ' . $peserta['kategori'] . '.';
                    $jenisFlash = 'warning';
                } else {
                    $flash = 'Suara belum berhasil disimpan. Silakan coba kembali.';
                    $jenisFlash = 'danger';
                }
            }
        }
    }
}

$stmt = $conn->prepare('SELECT kategori FROM voting WHERE user_id = ?');
$userId = (int)$_SESSION['id'];
$stmt->bind_param('i', $userId);
$stmt->execute();
$sudahMemilih = [];
$hasilSuara = $stmt->get_result();
while ($row = $hasilSuara->fetch_assoc()) {
    $sudahMemilih[$row['kategori']] = true;
}
$kontestan = $conn->query('SELECT id, nomor_peserta, nama, kategori, foto, asal_instansi FROM kontestan ORDER BY kategori, nomor_peserta, nama');
renderHeader('Voting', 'voting');
?>
<header class="page-hero"><div class="container"><p class="text-warning text-uppercase small fw-bold mb-2">Suara Anda menentukan</p><h1 class="fw-bold mb-2">Pilih Kontestan Favorit</h1><p class="mb-0 text-white-50">Setiap akun dapat memilih satu Kakang dan satu Senduk.</p></div></header>
<main class="container py-4">
    <?php if ($flash): ?><div class="alert alert-<?= h($jenisFlash) ?>" role="alert"><?= h($flash) ?></div><?php endif; ?>
    <?php if ($periode): ?><div class="alert alert-success"><strong><?= h($periode['nama_periode']) ?></strong> sedang berlangsung hingga <?= h(date('d-m-Y H:i', strtotime($periode['tanggal_selesai']))) ?>.</div><?php else: ?><div class="alert alert-warning">Periode voting saat ini belum dibuka atau sudah berakhir. Anda tetap dapat melihat profil kontestan.</div><?php endif; ?>
    <?php foreach (['Kakang', 'Senduk'] as $kategori): ?>
        <section class="mb-5"><div class="d-flex justify-content-between align-items-center mb-3"><h2 class="h3 fw-bold mb-0">Kategori <?= h($kategori) ?></h2><?php if (!empty($sudahMemilih[$kategori])): ?><span class="badge text-bg-success"><i class="bi bi-check-circle me-1"></i>Suara sudah diberikan</span><?php else: ?><span class="badge text-bg-secondary">Belum memilih</span><?php endif; ?></div>
            <div class="row g-4">
            <?php $ada = false; if ($kontestan) { $kontestan->data_seek(0); while ($peserta = $kontestan->fetch_assoc()): if ($peserta['kategori'] !== $kategori) continue; $ada = true; $foto = fotoKontestan($peserta['foto']); ?>
                <div class="col-sm-6 col-lg-4"><article class="card h-100 border-0 shadow-sm">
                    <?php if ($foto): ?><img src="<?= h($foto) ?>" class="card-img-top contestant-photo" alt="Foto <?= h($peserta['nama']) ?>"><?php else: ?><div class="contestant-photo bg-body-secondary d-flex align-items-center justify-content-center text-secondary">Foto belum tersedia</div><?php endif; ?>
                    <div class="card-body d-flex flex-column"><p class="text-muted small mb-1">Nomor <?= h($peserta['nomor_peserta']) ?></p><h3 class="h5 fw-bold"><?= h($peserta['nama']) ?></h3><p class="text-muted flex-grow-1"><?= h($peserta['asal_instansi'] ?: 'Kontestan ' . $kategori) ?></p><div class="d-flex gap-2"><a class="btn btn-outline-dark flex-fill" href="detail-kontestan.php?id=<?= (int)$peserta['id'] ?>">Profil</a>
                    <?php if (empty($sudahMemilih[$kategori]) && $periode): ?><form method="post" class="flex-fill" onsubmit="return confirm('Yakin dengan pilihan Anda? Suara tidak dapat diubah.');"><input type="hidden" name="csrf_token" value="<?= h($_SESSION['csrf_token']) ?>"><input type="hidden" name="kontestan_id" value="<?= (int)$peserta['id'] ?>"><button class="btn btn-warning w-100" type="submit">Pilih</button></form><?php elseif (!empty($sudahMemilih[$kategori])): ?><button class="btn btn-secondary flex-fill" disabled>Sudah memilih</button><?php else: ?><button class="btn btn-secondary flex-fill" disabled>Voting ditutup</button><?php endif; ?></div></div>
                </article></div>
            <?php endwhile; } if (!$ada): ?><div class="col-12"><div class="alert alert-light border">Belum ada kontestan untuk kategori <?= h($kategori) ?>.</div></div><?php endif; ?>
            </div>
        </section>
    <?php endforeach; ?>
    <p class="small text-muted">Pastikan pilihan Anda sudah benar. Suara yang sudah masuk tidak dapat diubah.</p>
</main>
<?php renderFooter(); ?>
