<?php
require_once __DIR__ . '/_common.php';
$periodeAktif = periodeAktif($conn);
$result = $conn->query("SELECT kategori, COUNT(*) AS total FROM voting GROUP BY kategori");
$total = ['Kakang' => 0, 'Senduk' => 0];
while ($row = $result->fetch_assoc()) {
    if (isset($total[$row['kategori']])) $total[$row['kategori']] = (int)$row['total'];
}
renderHeader('Informasi Hasil Pemilihan', 'hasil');
?>
<header class="page-hero"><div class="container"><p class="text-warning text-uppercase small fw-bold mb-2">Transparansi pemilihan</p><h1 class="fw-bold mb-2">Informasi Hasil</h1><p class="mb-0 text-white-50">Pantau status periode dan rekap suara pemilihan Kakang Senduk.</p></div></header>
<main class="container py-5">
    <section class="card border-0 shadow-sm mb-4"><div class="card-body p-4">
        <h2 class="h4 fw-bold">Status pemilihan</h2>
        <?php if ($periodeAktif): ?><p class="mb-1"><span class="badge text-bg-success">Sedang berlangsung</span> <strong class="ms-2"><?= h($periodeAktif['nama_periode']) ?></strong></p><p class="text-muted mb-0">Voting ditutup pada <?= h(date('d-m-Y H:i', strtotime($periodeAktif['tanggal_selesai']))) ?>. Klasemen saat ini bersifat sementara.</p><?php else: ?><p class="text-muted mb-0">Tidak ada periode voting yang sedang berlangsung. Lihat klasemen untuk rekap suara yang tercatat.</p><?php endif; ?>
    </div></section>
    <div class="row g-3 mb-4"><div class="col-md-6"><div class="card border-0 shadow-sm h-100"><div class="card-body p-4"><div class="text-muted">Suara kategori Kakang</div><div class="display-5 fw-bold text-danger"><?= $total['Kakang'] ?></div></div></div></div><div class="col-md-6"><div class="card border-0 shadow-sm h-100"><div class="card-body p-4"><div class="text-muted">Suara kategori Senduk</div><div class="display-5 fw-bold text-danger"><?= $total['Senduk'] ?></div></div></div></div></div>
    <div class="d-flex flex-wrap gap-2"><a href="../klasemen.php" class="btn btn-dark"><i class="bi bi-trophy me-1"></i>Lihat Klasemen Sementara</a><a href="kontestan.php" class="btn btn-outline-dark">Jelajahi Kontestan</a></div>
</main>
<?php renderFooter(); ?>
