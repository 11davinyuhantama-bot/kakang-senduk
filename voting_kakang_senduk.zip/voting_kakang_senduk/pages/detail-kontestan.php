<?php
require_once __DIR__ . '/_common.php';
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);
$stmt = $conn->prepare('SELECT * FROM kontestan WHERE id = ?');
$stmt->bind_param('i', $id);
$stmt->execute();
$peserta = $stmt->get_result()->fetch_assoc();
if (!$peserta) {
    http_response_code(404);
}
renderHeader($peserta ? 'Profil ' . $peserta['nama'] : 'Kontestan Tidak Ditemukan', 'kontestan');
?>
<main class="container py-5">
    <?php if (!$peserta): ?>
        <div class="alert alert-warning"><h1 class="h4">Kontestan tidak ditemukan</h1><a href="kontestan.php" class="alert-link">Kembali ke daftar kontestan</a></div>
    <?php else: $foto = fotoKontestan($peserta['foto']); ?>
        <a href="kontestan.php" class="text-decoration-none text-secondary"><i class="bi bi-arrow-left me-1"></i>Kembali ke kontestan</a>
        <div class="row g-4 mt-2 align-items-start">
            <div class="col-lg-5"><?php if ($foto): ?><img src="<?= h($foto) ?>" class="profile-photo rounded-4 shadow-sm" alt="Foto <?= h($peserta['nama']) ?>"><?php else: ?><div class="profile-photo rounded-4 bg-body-secondary d-flex align-items-center justify-content-center">Foto belum tersedia</div><?php endif; ?></div>
            <div class="col-lg-7">
                <span class="badge text-bg-danger mb-2"><?= h($peserta['kategori']) ?> · No. <?= h($peserta['nomor_peserta']) ?></span>
                <h1 class="display-6 fw-bold"><?= h($peserta['nama']) ?></h1>
                <p class="lead text-secondary"><?= h($peserta['asal_instansi'] ?: 'Kontestan Pemilihan Kakang Senduk Ponorogo') ?></p>
                <dl class="row">
                    <?php if ($peserta['tempat_lahir'] || $peserta['tanggal_lahir']): ?><dt class="col-sm-3">Tempat, tanggal lahir</dt><dd class="col-sm-9"><?= h(trim(($peserta['tempat_lahir'] ?? '') . (!empty($peserta['tanggal_lahir']) ? ', ' . date('d-m-Y', strtotime($peserta['tanggal_lahir'])) : ''))) ?></dd><?php endif; ?>
                </dl>
                <?php foreach (['deskripsi' => 'Profil', 'visi' => 'Visi', 'misi' => 'Misi', 'prestasi' => 'Prestasi'] as $field => $label): if (trim((string)$peserta[$field]) !== ''): ?>
                    <section class="mb-4"><h2 class="h5 fw-bold"><?= h($label) ?></h2><div class="text-secondary"><?= nl2br(h($peserta[$field])) ?></div></section>
                <?php endif; endforeach; ?>
                <a href="voting.php?kategori=<?= rawurlencode($peserta['kategori']) ?>" class="btn btn-warning btn-lg"><i class="bi bi-check2-circle me-1"></i>Pilih <?= h($peserta['nama']) ?></a>
            </div>
        </div>
    <?php endif; ?>
</main>
<?php renderFooter(); ?>
