<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
date_default_timezone_set('Asia/Jakarta');
require_once __DIR__ . '/../config/koneksi.php';

function h($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function fotoKontestan(?string $foto): ?string
{
    $foto = trim((string) $foto);
    if ($foto === '') {
        return null;
    }

    $namaFile = basename($foto);
    if (is_file(__DIR__ . '/../assets/img/kontestan/' . $namaFile)) {
        return '../assets/img/kontestan/' . rawurlencode($namaFile);
    }
    if (is_file(__DIR__ . '/../uploads/' . $namaFile)) {
        return '../uploads/' . rawurlencode($namaFile);
    }
    return null;
}

function periodeAktif(mysqli $conn): ?array
{
    $result = $conn->query("SELECT * FROM periode_voting WHERE status = 'Aktif' ORDER BY id DESC LIMIT 1");
    $periode = $result ? $result->fetch_assoc() : null;
    if (!$periode) {
        return null;
    }

    $sekarang = date('Y-m-d H:i:s');
    return $sekarang >= $periode['tanggal_mulai'] && $sekarang <= $periode['tanggal_selesai']
        ? $periode
        : null;
}

function pemilihLogin(): bool
{
    return isset($_SESSION['id'], $_SESSION['role']) && $_SESSION['role'] === 'pemilih';
}

function renderHeader(string $judul, string $aktif, bool $halamanRoot = false): void
{
    $login = isset($_SESSION['id']);
    $pemilih = pemilihLogin();
    $linkBeranda = $halamanRoot ? 'index.php' : '../index.php';
    $linkKontestan = $halamanRoot ? 'pages/kontestan.php' : 'kontestan.php';
    $linkKlasemen = $halamanRoot ? 'klasemen.php' : '../klasemen.php';
    $linkHasil = $halamanRoot ? 'pages/hasil.php' : 'hasil.php';
    $linkVoting = $halamanRoot ? 'pages/voting.php' : 'voting.php';
    $linkLogin = $halamanRoot ? 'auth/login.php' : '../auth/login.php';
    $linkRegister = $halamanRoot ? 'auth/register.php' : '../auth/register.php';
    $linkLogout = $halamanRoot ? 'auth/logout.php' : '../auth/logout.php';
    ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= h($judul) ?> | Kakang Senduk Ponorogo</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
        <link rel="stylesheet" href="../assets/css/style.css">
        <style>
            body { background:#f7f5f3; }
            .public-nav { background:#451018; }
            .public-nav .nav-link { color:#f5e8e8; }
            .public-nav .nav-link.active, .public-nav .nav-link:hover { color:#e9b94e; }
            .page-hero { background:linear-gradient(120deg,#451018,#7c2631); color:#fff; padding:42px 0; }
            .contestant-photo { height:280px; object-fit:cover; }
            .profile-photo { width:100%; max-height:520px; object-fit:cover; }
            .public-footer { background:#451018; color:#f5e8e8; }
        </style>
    </head>
    <body>
    <nav class="navbar navbar-expand-lg navbar-dark public-nav">
        <div class="container">
            <a class="navbar-brand fw-bold" href="<?= h($linkBeranda) ?>">KAKANG SENDUK</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#publicMenu" aria-label="Buka menu"><span class="navbar-toggler-icon"></span></button>
            <div class="collapse navbar-collapse" id="publicMenu">
                <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-2">
                    <li class="nav-item"><a class="nav-link <?= $aktif === 'beranda' ? 'active' : '' ?>" href="<?= h($linkBeranda) ?>">Beranda</a></li>
                    <li class="nav-item"><a class="nav-link <?= $aktif === 'kontestan' ? 'active' : '' ?>" href="<?= h($linkKontestan) ?>">Kontestan</a></li>
                    <li class="nav-item"><a class="nav-link <?= $aktif === 'klasemen' ? 'active' : '' ?>" href="<?= h($linkKlasemen) ?>">Klasemen</a></li>
                    <li class="nav-item"><a class="nav-link <?= $aktif === 'hasil' ? 'active' : '' ?>" href="<?= h($linkHasil) ?>">Informasi Hasil</a></li>
                    <?php if ($login): ?>
                        <?php if ($pemilih): ?><li class="nav-item"><a class="btn btn-warning btn-sm" href="<?= h($linkVoting) ?>"><i class="bi bi-check2-circle me-1"></i>Voting</a></li><?php endif; ?>
                        <li class="nav-item"><span class="nav-link">Halo, <?= h($_SESSION['nama'] ?? 'Pemilih') ?></span></li>
                        <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="<?= h($linkLogout) ?>">Keluar</a></li>
                    <?php else: ?>
                        <li class="nav-item"><a class="btn btn-outline-light btn-sm" href="<?= h($linkLogin) ?>">Masuk</a></li>
                        <li class="nav-item"><a class="btn btn-warning btn-sm" href="<?= h($linkRegister) ?>">Daftar</a></li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </nav>
    <?php
}

function renderFooter(): void
{
    ?>
    <footer class="public-footer text-center py-4 mt-5">© <?= date('Y') ?> Pemilihan Kakang Senduk Ponorogo</footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    </body>
    </html>
    <?php
}
