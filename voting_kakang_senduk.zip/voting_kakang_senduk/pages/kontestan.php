<?php
require_once __DIR__ . '/_common.php';
$kategori = $_GET['kategori'] ?? '';
$kategoriValid = in_array($kategori, ['Kakang', 'Senduk'], true);
$sql = 'SELECT id, nomor_peserta, nama, kategori, foto, asal_instansi, deskripsi FROM kontestan';
if ($kategoriValid) {
    $stmt = $conn->prepare($sql . ' WHERE kategori = ? ORDER BY nomor_peserta, nama');
    $stmt->bind_param('s', $kategori);
    $stmt->execute();
    $kontestan = $stmt->get_result();
} else {
    $kontestan = $conn->query($sql . ' ORDER BY kategori, nomor_peserta, nama');
}
renderHeader('Daftar Kontestan', 'kontestan');
?>
<header class="page-hero"><div class="container"><p class="text-warning text-uppercase small fw-bold mb-2">Kenali para peserta</p><h1 class="fw-bold mb-2">Kontestan Kakang &amp; Senduk</h1><p class="mb-0 text-white-50">Lihat profil, visi, misi, dan prestasi setiap kontestan.</p></div></header>
<main class="container py-4">
    <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
        <div class="btn-group" role="group" aria-label="Filter kategori">
            <a class="btn <?= !$kategoriValid ? 'btn-dark' : 'btn-outline-dark' ?>" href="kontestan.php">Semua</a>
            <a class="btn <?= $kategori === 'Kakang' ? 'btn-dark' : 'btn-outline-dark' ?>" href="?kategori=Kakang">Kakang</a>
            <a class="btn <?= $kategori === 'Senduk' ? 'btn-dark' : 'btn-outline-dark' ?>" href="?kategori=Senduk">Senduk</a>
        </div>
        <a href="voting.php" class="btn btn-warning"><i class="bi bi-check2-circle me-1"></i>Voting Sekarang</a>
    </div>
    <?php if ($kontestan && $kontestan->num_rows): ?>
        <div class="row g-4">
            <?php while ($peserta = $kontestan->fetch_assoc()): $foto = fotoKontestan($peserta['foto']); ?>
                <div class="col-sm-6 col-lg-4">
                    <article class="card h-100 border-0 shadow-sm">
                        <?php if ($foto): ?><img src="<?= h($foto) ?>" class="card-img-top contestant-photo" alt="Foto <?= h($peserta['nama']) ?>"><?php else: ?><div class="contestant-photo bg-body-secondary d-flex align-items-center justify-content-center text-secondary">Foto belum tersedia</div><?php endif; ?>
                        <div class="card-body d-flex flex-column">
                            <div class="d-flex justify-content-between mb-2"><span class="badge text-bg-danger"><?= h($peserta['kategori']) ?></span><span class="text-muted small">No. <?= h($peserta['nomor_peserta']) ?></span></div>
                            <h2 class="h5 fw-bold"><?= h($peserta['nama']) ?></h2>
                            <?php if (!empty($peserta['asal_instansi'])): ?><p class="text-muted small mb-2"><?= h($peserta['asal_instansi']) ?></p><?php endif; ?>
                            <p class="text-secondary flex-grow-1"><?= h(mb_strimwidth(trim(strip_tags((string)$peserta['deskripsi'])), 0, 135, '…')) ?></p>
                            <a href="detail-kontestan.php?id=<?= (int)$peserta['id'] ?>" class="btn btn-outline-dark">Lihat Profil</a>
                        </div>
                    </article>
                </div>
            <?php endwhile; ?>
        </div>
    <?php else: ?><div class="alert alert-info">Belum ada data kontestan<?= $kategoriValid ? ' kategori ' . h($kategori) : '' ?>.</div><?php endif; ?>
</main>
<?php renderFooter(); ?>
