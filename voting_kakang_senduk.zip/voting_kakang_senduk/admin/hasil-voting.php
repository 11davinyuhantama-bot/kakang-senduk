
<?php
session_start();
require_once '../config/koneksi.php';

// Cek akses admin
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Total seluruh suara
$totalQuery = $conn->query("SELECT COUNT(*) AS total FROM voting");
$totalSuara = $totalQuery->fetch_assoc()['total'];

// Total suara Kakang
$kakangQuery = $conn->query("
    SELECT COUNT(*) AS total
    FROM voting
    WHERE kategori = 'Kakang'
");
$totalKakang = $kakangQuery->fetch_assoc()['total'];

// Total suara Senduk
$sendukQuery = $conn->query("
    SELECT COUNT(*) AS total
    FROM voting
    WHERE kategori = 'Senduk'
");
$totalSenduk = $sendukQuery->fetch_assoc()['total'];

// Hasil perolehan suara setiap kontestan
$result = $conn->query("
    SELECT
        k.id,
        k.nomor_peserta,
        k.nama,
        k.kategori,
        k.foto,
        COUNT(v.id) AS jumlah_suara
    FROM kontestan k
    LEFT JOIN voting v ON k.id = v.kontestan_id
    GROUP BY
        k.id,
        k.nomor_peserta,
        k.nama,
        k.kategori,
        k.foto
    ORDER BY k.kategori ASC, jumlah_suara DESC
");

$hasil = [];

while ($row = $result->fetch_assoc()) {
    $hasil[] = $row;
}

// Fungsi keamanan output
function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hasil Voting - Admin</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">
</head>

<body>
<?php $sidebarPrefix = ''; $sitePrefix = '../'; include 'sidebar.php'; ?>
<main class="main-content">
<div class="container-fluid py-2">

    <h3 class="mb-1">Hasil Voting</h3>
    <p class="text-muted">Rekapitulasi perolehan suara kontestan Kakang Senduk.</p>

    <!-- Ringkasan -->
    <div class="row g-3 mb-4">

        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <p class="text-muted mb-1">Total Seluruh Suara</p>
                    <h2><?= (int) $totalSuara ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <p class="text-muted mb-1">Suara Kakang</p>
                    <h2><?= (int) $totalKakang ?></h2>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card shadow-sm border-0">
                <div class="card-body">
                    <p class="text-muted mb-1">Suara Senduk</p>
                    <h2><?= (int) $totalSenduk ?></h2>
                </div>
            </div>
        </div>

    </div>

    <!-- Tabel hasil -->
    <div class="card shadow-sm">
        <div class="card-header bg-white">
            <strong>Perolehan Suara Kontestan</strong>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover mb-0 align-middle">

                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nomor Peserta</th>
                        <th>Nama Kontestan</th>
                        <th>Kategori</th>
                        <th>Jumlah Suara</th>
                    </tr>
                </thead>

                <tbody>
                    <?php if (count($hasil) > 0): ?>

                        <?php foreach ($hasil as $i => $data): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><?= e($data['nomor_peserta']) ?></td>
                                <td><?= e($data['nama']) ?></td>
                                <td>
                                    <span class="badge bg-primary">
                                        <?= e($data['kategori']) ?>
                                    </span>
                                </td>
                                <td>
                                    <strong><?= (int) $data['jumlah_suara'] ?></strong>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    <?php else: ?>
                        <tr>
                            <td colspan="5" class="text-center text-muted">
                                Belum ada data kontestan.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-3">
        Kembali ke Dashboard
    </a>

</div>
</main>

</body>
</html>
