
<?php
session_start();

require_once '../config/koneksi.php';

// Proteksi halaman admin
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Fungsi mengambil jumlah data
function hitungData($conn, $sql) {
    $result = mysqli_query($conn, $sql);

    if (!$result) {
        return 0;
    }

    $data = mysqli_fetch_assoc($result);
    return $data['total'] ?? 0;
}

// Statistik dashboard
$totalKontestan = hitungData($conn, "SELECT COUNT(*) AS total FROM kontestan");

$totalKakang = hitungData($conn,
    "SELECT COUNT(*) AS total FROM kontestan WHERE kategori = 'Kakang'");

$totalSenduk = hitungData($conn,
    "SELECT COUNT(*) AS total FROM kontestan WHERE kategori = 'Senduk'");

$totalPemilih = hitungData($conn,
    "SELECT COUNT(*) AS total FROM users WHERE role = 'pemilih'");

$totalVoting = hitungData($conn,
    "SELECT COUNT(*) AS total FROM voting");

$suaraKakang = hitungData($conn,
    "SELECT COUNT(*) AS total FROM voting WHERE kategori = 'Kakang'");

$suaraSenduk = hitungData($conn,
    "SELECT COUNT(*) AS total FROM voting WHERE kategori = 'Senduk'");

// Mengambil periode voting aktif
$queryPeriode = mysqli_query($conn,
    "SELECT * FROM periode_voting
     WHERE status = 'Aktif'
     ORDER BY id DESC LIMIT 1");

$periode = $queryPeriode ? mysqli_fetch_assoc($queryPeriode) : null;

// Mengambil klasemen Kakang
$queryKakang = mysqli_query($conn, "
    SELECT 
        k.id,
        k.nomor_peserta,
        k.nama,
        k.foto,
        COUNT(v.id) AS jumlah_suara
    FROM kontestan k
    LEFT JOIN voting v ON k.id = v.kontestan_id
    WHERE k.kategori = 'Kakang'
    GROUP BY k.id, k.nomor_peserta, k.nama, k.foto
    ORDER BY jumlah_suara DESC, k.nomor_peserta ASC
    LIMIT 5
");

// Mengambil klasemen Senduk
$querySenduk = mysqli_query($conn, "
    SELECT 
        k.id,
        k.nomor_peserta,
        k.nama,
        k.foto,
        COUNT(v.id) AS jumlah_suara
    FROM kontestan k
    LEFT JOIN voting v ON k.id = v.kontestan_id
    WHERE k.kategori = 'Senduk'
    GROUP BY k.id, k.nomor_peserta, k.nama, k.foto
    ORDER BY jumlah_suara DESC, k.nomor_peserta ASC
    LIMIT 5
");

// Persentase suara
$persenKakang = $totalVoting > 0
    ? round(($suaraKakang / $totalVoting) * 100, 1)
    : 0;

$persenSenduk = $totalVoting > 0
    ? round(($suaraSenduk / $totalVoting) * 100, 1)
    : 0;

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function urlFotoKontestan($foto) {
    $namaFile = basename(trim((string)$foto));
    if ($namaFile === '') return null;
    if (is_file(__DIR__ . '/../assets/img/kontestan/' . $namaFile)) {
        return '../assets/img/kontestan/' . rawurlencode($namaFile);
    }
    if (is_file(__DIR__ . '/../uploads/' . $namaFile)) {
        return '../uploads/' . rawurlencode($namaFile);
    }
    return null;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard Admin | Kakang Senduk Ponorogo</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        :root {
            --maroon: #681d25;
            --maroon-dark: #451018;
            --gold: #e9b94e;
            --background: #f5f6fa;
        }

        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            background: var(--background);
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            left: 0;
            top: 0;
            background: linear-gradient(180deg, var(--maroon-dark), var(--maroon));
            color: white;
            padding: 25px 18px;
            z-index: 1000;
            overflow-y: auto;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 8px 25px;
            border-bottom: 1px solid rgba(255,255,255,.15);
        }

        .brand-logo {
            width: 48px;
            height: 48px;
            background: var(--gold);
            color: var(--maroon-dark);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 14px;
            font-weight: 900;
            font-size: 20px;
        }

        .brand h5 {
            font-size: 15px;
            margin: 0;
            font-weight: 800;
        }

        .brand small {
            font-size: 11px;
            color: #e9c7c7;
        }

        .menu-label {
            font-size: 11px;
            color: #d5a9a9;
            margin: 28px 10px 12px;
            text-transform: uppercase;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #f1dddd;
            text-decoration: none;
            padding: 12px 14px;
            border-radius: 10px;
            margin-bottom: 6px;
            font-size: 14px;
            transition: .2s;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: var(--gold);
            color: var(--maroon-dark);
            font-weight: 700;
        }

        .sidebar a i {
            font-size: 18px;
        }

        .main-content {
            margin-left: 260px;
            padding: 25px 30px;
        }

        .topbar {
            display: flex;
            justify-content: space-between;
            align-items: center;
            background: white;
            padding: 17px 23px;
            border-radius: 14px;
            margin-bottom: 28px;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
        }

        .topbar h5 {
            font-weight: 800;
            color: var(--maroon-dark);
            margin: 0;
        }

        .admin-profile {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .admin-avatar {
            width: 42px;
            height: 42px;
            background: #f4e5c1;
            color: var(--maroon);
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 50%;
            font-size: 20px;
        }

        .welcome {
            margin-bottom: 25px;
        }

        .welcome h3 {
            font-weight: 800;
            color: var(--maroon-dark);
        }

        .welcome p {
            color: #777;
        }

        .stat-card {
            background: white;
            border-radius: 15px;
            padding: 22px;
            height: 100%;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
            transition: .2s;
        }

        .stat-card:hover {
            transform: translateY(-4px);
        }

        .stat-icon {
            width: 48px;
            height: 48px;
            display: flex;
            align-items: center;
            justify-content: center;
            border-radius: 13px;
            font-size: 23px;
            margin-bottom: 15px;
        }

        .icon-maroon {
            background: #f7e8e9;
            color: var(--maroon);
        }

        .icon-gold {
            background: #fff4d7;
            color: #ad7910;
        }

        .icon-green {
            background: #e2f5e9;
            color: #198754;
        }

        .icon-blue {
            background: #e3efff;
            color: #0d6efd;
        }

        .stat-card h3 {
            font-size: 28px;
            font-weight: 800;
            color: #252525;
            margin: 0;
        }

        .stat-card p {
            color: #888;
            font-size: 13px;
            margin: 5px 0 0;
        }

        .section-card {
            background: white;
            padding: 23px;
            border-radius: 15px;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
            height: 100%;
        }

        .section-title {
            font-weight: 800;
            color: var(--maroon-dark);
            font-size: 17px;
        }

        .period-card {
            background: linear-gradient(120deg, #681d25, #922f3c);
            color: white;
            padding: 25px;
            border-radius: 15px;
            margin-bottom: 25px;
        }

        .period-card h5 {
            font-weight: 800;
        }

        .period-status {
            display: inline-block;
            padding: 6px 12px;
            border-radius: 20px;
            background: var(--gold);
            color: #451018;
            font-size: 12px;
            font-weight: 800;
        }

        .table thead th {
            background: #faf5f5;
            color: var(--maroon);
            font-size: 12px;
            white-space: nowrap;
        }

        .table tbody td {
            font-size: 13px;
            vertical-align: middle;
        }

        .participant-photo {
            width: 38px;
            height: 38px;
            object-fit: cover;
            border-radius: 50%;
            background: #eee;
        }

        .vote-number {
            color: var(--maroon);
            font-weight: 800;
        }

        .progress {
            height: 9px;
            background: #eee;
            border-radius: 10px;
        }

        .progress-bar {
            background: var(--maroon);
        }

        .progress-bar.gold {
            background: #d6a32c;
        }

        .quick-link {
            text-decoration: none;
            color: var(--maroon);
            background: #faf5f5;
            border-radius: 12px;
            padding: 17px 10px;
            display: block;
            text-align: center;
            height: 100%;
            transition: .2s;
        }

        .quick-link:hover {
            background: #f3e3e4;
            transform: translateY(-3px);
            color: var(--maroon-dark);
        }

        .quick-link i {
            font-size: 25px;
            display: block;
            margin-bottom: 8px;
        }

        .quick-link span {
            font-size: 12px;
            font-weight: 700;
        }

        @media(max-width: 900px) {
            .sidebar {
                width: 75px;
                padding: 20px 10px;
            }

            .brand {
                justify-content: center;
                padding: 0 0 20px;
            }

            .brand-text,
            .sidebar .menu-label,
            .sidebar a span {
                display: none;
            }

            .sidebar a {
                justify-content: center;
                padding: 13px;
            }

            .main-content {
                margin-left: 75px;
                padding: 18px;
            }
        }

        @media(max-width: 576px) {
            .main-content {
                padding: 12px;
            }

            .topbar {
                padding: 13px;
            }

            .topbar h5 {
                font-size: 15px;
            }

            .admin-profile small {
                display: none;
            }
        }
    </style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">

    <div class="brand">

        <div class="brand-logo">KS</div>

        <div class="brand-text">
            <h5>KAKANG SENDUK</h5>
            <small>ADMIN PANEL</small>
        </div>

    </div>


    <div class="menu-label">Menu Utama</div>

    <a href="dashboard.php" class="active">
        <i class="bi bi-grid-1x2-fill"></i>
        <span>Dashboard</span>
    </a>

    <a href="kontestan.php">
        <i class="bi bi-people-fill"></i>
        <span>Data Kontestan</span>
    </a>

    <a href="pengguna.php">
        <i class="bi bi-person-badge-fill"></i>
        <span>Data Pengguna</span>
    </a>


    <div class="menu-label">Pemilihan</div>

    <a href="periode.php">
        <i class="bi bi-calendar-event-fill"></i>
        <span>Periode Voting</span>
    </a>

    <a href="hasil-voting.php">
        <i class="bi bi-bar-chart-fill"></i>
        <span>Hasil Voting</span>
    </a>

    <a href="../klasemen.php">
        <i class="bi bi-trophy-fill"></i>
        <span>Klasemen</span>
    </a>


    <div class="menu-label">Lainnya</div>

    <a href="../index.php">
        <i class="bi bi-house-fill"></i>
        <span>Lihat Website</span>
    </a>

    <a href="../auth/logout.php"
       onclick="return confirm('Yakin ingin logout?')">
        <i class="bi bi-box-arrow-left"></i>
        <span>Logout</span>
    </a>

</aside>

<main class="main-content">

    <!-- PERIODE VOTING -->
    <div class="period-card">

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3">

            <div>
                <h5>
                    <i class="bi bi-calendar-check me-2"></i>
                    Periode Voting
                </h5>

                <?php if ($periode): ?>

                    <h4 class="fw-bold">
                        <?= e($periode['nama_periode']) ?>
                    </h4>

                    <small>
                        Mulai:
                        <?= date('d-m-Y H:i', strtotime($periode['tanggal_mulai'])) ?>
                    </small>

                    <br>

                    <small>
                        Selesai:
                        <?= date('d-m-Y H:i', strtotime($periode['tanggal_selesai'])) ?>
                    </small>

                <?php else: ?>

                    <h5>Belum Ada Periode Voting Aktif</h5>

                    <small>Silakan atur periode voting terlebih dahulu.</small>

                <?php endif; ?>
            </div>

            <div>
                <?php if ($periode): ?>
                    <span class="period-status">
                        <i class="bi bi-circle-fill me-1"></i>
                        VOTING AKTIF
                    </span>
                <?php else: ?>
                    <span class="badge bg-secondary p-2">
                        VOTING NONAKTIF
                    </span>
                <?php endif; ?>
            </div>

        </div>

    </div>


    <!-- STATISTIK -->
    <div class="row g-3 mb-4">

        <div class="col-6 col-lg-3">
            <div class="stat-card">

                <div class="stat-icon icon-maroon">
                    <i class="bi bi-people-fill"></i>
                </div>

                <h3><?= number_format($totalKontestan) ?></h3>
                <p>Total Kontestan</p>

            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="stat-card">

                <div class="stat-icon icon-gold">
                    <i class="bi bi-person-vcard-fill"></i>
                </div>

                <h3><?= number_format($totalPemilih) ?></h3>
                <p>Total Pemilih</p>

            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="stat-card">

                <div class="stat-icon icon-green">
                    <i class="bi bi-check-circle-fill"></i>
                </div>

                <h3><?= number_format($totalVoting) ?></h3>
                <p>Total Suara Masuk</p>

            </div>
        </div>

        <div class="col-6 col-lg-3">
            <div class="stat-card">

                <div class="stat-icon icon-blue">
                    <i class="bi bi-person-hearts"></i>
                </div>

                <h3><?= number_format($totalKakang + $totalSenduk) ?></h3>
                <p>Kontestan Kakang & Senduk</p>

            </div>
        </div>

    </div>


    <!-- STATISTIK KATEGORI -->
    <div class="row g-3 mb-4">

        <div class="col-md-6">

            <div class="section-card">

                <h6 class="section-title mb-3">
                    <i class="bi bi-person-fill me-2"></i>
                    Statistik Kakang
                </h6>

                <h3 class="fw-bold"><?= number_format($totalKakang) ?></h3>

                <p class="text-muted small">Jumlah Kontestan Kakang</p>

                <div class="progress mb-2">
                    <div class="progress-bar"
                         style="width: <?= $persenKakang ?>%">
                    </div>
                </div>

                <small class="text-muted">
                    <?= number_format($suaraKakang) ?> suara masuk
                    (<?= $persenKakang ?>%)
                </small>

            </div>

        </div>

        <div class="col-md-6">

            <div class="section-card">

                <h6 class="section-title mb-3">
                    <i class="bi bi-person-fill me-2"></i>
                    Statistik Senduk
                </h6>

                <h3 class="fw-bold"><?= number_format($totalSenduk) ?></h3>

                <p class="text-muted small">Jumlah Kontestan Senduk</p>

                <div class="progress mb-2">
                    <div class="progress-bar gold"
                         style="width: <?= $persenSenduk ?>%">
                    </div>
                </div>

                <small class="text-muted">
                    <?= number_format($suaraSenduk) ?> suara masuk
                    (<?= $persenSenduk ?>%)
                </small>

            </div>

        </div>

    </div>


    <!-- QUICK MENU -->
    <div class="section-card mb-4">

        <h6 class="section-title mb-3">
            <i class="bi bi-lightning-charge-fill me-2"></i>
            Akses Cepat
        </h6>

        <div class="row g-3">

            <div class="col-6 col-md-3">
                <a href="kontestan.php" class="quick-link">
                    <i class="bi bi-person-plus-fill"></i>
                    <span>Tambah Kontestan</span>
                </a>
            </div>

            <div class="col-6 col-md-3">
                <a href="pengguna.php" class="quick-link">
                    <i class="bi bi-people-fill"></i>
                    <span>Kelola Pengguna</span>
                </a>
            </div>

            <div class="col-6 col-md-3">
                <a href="periode.php" class="quick-link">
                    <i class="bi bi-calendar-plus-fill"></i>
                    <span>Atur Periode</span>
                </a>
            </div>

            <div class="col-6 col-md-3">
                <a href="hasil-voting.php" class="quick-link">
                    <i class="bi bi-bar-chart-line-fill"></i>
                    <span>Lihat Hasil</span>
                </a>
            </div>

        </div>

    </div>


    <!-- KLASEMEN -->
    <div class="row g-3 mb-4">

        <!-- KAKANG -->
        <div class="col-lg-6">

            <div class="section-card">

                <h6 class="section-title mb-3">
                    <i class="bi bi-trophy-fill me-2"></i>
                    Klasemen Kakang
                </h6>

                <div class="table-responsive">

                    <table class="table table-hover">

                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Kontestan</th>
                                <th>Suara</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if ($queryKakang && mysqli_num_rows($queryKakang) > 0): ?>

                            <?php $rank = 1; ?>

                            <?php while ($row = mysqli_fetch_assoc($queryKakang)): ?>

                                <tr>

                                    <td>
                                        <strong><?= $rank++ ?></strong>
                                    </td>

                                    <td>
                                        <div class="d-flex align-items-center gap-2">

                                            <?php if ($fotoUrl = urlFotoKontestan($row['foto'])): ?>

                                                <img src="<?= e($fotoUrl) ?>"
                                                     class="participant-photo"
                                                     alt="Foto kontestan">

                                            <?php else: ?>

                                                <div class="participant-photo d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-person"></i>
                                                </div>

                                            <?php endif; ?>

                                            <div>
                                                <strong><?= e($row['nama']) ?></strong>
                                                <br>
                                                <small class="text-muted">
                                                    <?= e($row['nomor_peserta']) ?>
                                                </small>
                                            </div>

                                        </div>
                                    </td>

                                    <td class="vote-number">
                                        <?= number_format($row['jumlah_suara']) ?>
                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="3" class="text-center text-muted">
                                    Belum ada data kontestan.
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>


        <!-- SENDUK -->
        <div class="col-lg-6">

            <div class="section-card">

                <h6 class="section-title mb-3">
                    <i class="bi bi-trophy-fill me-2"></i>
                    Klasemen Senduk
                </h6>

                <div class="table-responsive">

                    <table class="table table-hover">

                        <thead>
                            <tr>
                                <th>Rank</th>
                                <th>Kontestan</th>
                                <th>Suara</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if ($querySenduk && mysqli_num_rows($querySenduk) > 0): ?>

                            <?php $rank = 1; ?>

                            <?php while ($row = mysqli_fetch_assoc($querySenduk)): ?>

                                <tr>

                                    <td>
                                        <strong><?= $rank++ ?></strong>
                                    </td>

                                    <td>
                                        <div class="d-flex align-items-center gap-2">

                                            <?php if ($fotoUrl = urlFotoKontestan($row['foto'])): ?>

                                                <img src="<?= e($fotoUrl) ?>"
                                                     class="participant-photo"
                                                     alt="Foto kontestan">

                                            <?php else: ?>

                                                <div class="participant-photo d-flex align-items-center justify-content-center">
                                                    <i class="bi bi-person"></i>
                                                </div>

                                            <?php endif; ?>

                                            <div>
                                                <strong><?= e($row['nama']) ?></strong>
                                                <br>
                                                <small class="text-muted">
                                                    <?= e($row['nomor_peserta']) ?>
                                                </small>
                                            </div>

                                        </div>
                                    </td>

                                    <td class="vote-number">
                                        <?= number_format($row['jumlah_suara']) ?>
                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="3" class="text-center text-muted">
                                    Belum ada data kontestan.
                                </td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>


    <!-- FOOTER -->
    <div class="text-center text-muted py-3 small">

        © <?= date('Y') ?> Pemilihan Kakang Senduk Ponorogo.

        <br>

        Administrator Panel

    </div>

</main>

</body>
</html>
