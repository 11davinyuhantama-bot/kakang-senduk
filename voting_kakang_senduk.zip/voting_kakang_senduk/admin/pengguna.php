
<?php
session_start();
require_once '../config/koneksi.php';

// Proteksi admin
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// CSRF Token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$pesan = '';
$jenisPesan = 'success';

function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

// Flash message
if (isset($_SESSION['flash'])) {
    $pesan = $_SESSION['flash']['pesan'];
    $jenisPesan = $_SESSION['flash']['jenis'];
    unset($_SESSION['flash']);
}

// ============================
// PROSES FORM
// ============================
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        if (!hash_equals(
            $_SESSION['csrf_token'],
            $_POST['csrf_token'] ?? ''
        )) {
            throw new Exception('Permintaan tidak valid. Refresh halaman.');
        }

        $aksi = $_POST['aksi'] ?? '';

        // ============================
        // TAMBAH PENGGUNA
        // ============================
        if ($aksi === 'tambah') {

            $nama = trim($_POST['nama'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $noHp = trim($_POST['no_hp'] ?? '');
            $password = $_POST['password'] ?? '';
            $role = $_POST['role'] ?? 'pemilih';

            if ($nama === '' || $email === '' || $password === '') {
                throw new Exception('Nama, email, dan password wajib diisi.');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Format email tidak valid.');
            }

            if (!in_array($role, ['admin', 'pemilih'], true)) {
                throw new Exception('Role tidak valid.');
            }

            if (strlen($password) < 8) {
                throw new Exception('Password minimal 8 karakter.');
            }

            // Cek email
            $cek = mysqli_prepare($conn,
                "SELECT id FROM users WHERE email = ?");

            mysqli_stmt_bind_param($cek, "s", $email);
            mysqli_stmt_execute($cek);

            if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {
                throw new Exception('Email sudah terdaftar.');
            }

            $hash = password_hash($password, PASSWORD_DEFAULT);

            $stmt = mysqli_prepare($conn, "
                INSERT INTO users (nama, email, no_hp, password, role)
                VALUES (?, ?, ?, ?, ?)
            ");

            mysqli_stmt_bind_param(
                $stmt,
                "sssss",
                $nama,
                $email,
                $noHp,
                $hash,
                $role
            );

            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception('Gagal menambahkan pengguna.');
            }

            $_SESSION['flash'] = [
                'pesan' => 'Pengguna berhasil ditambahkan!',
                'jenis' => 'success'
            ];
        }

        // ============================
        // EDIT PENGGUNA
        // ============================
        elseif ($aksi === 'edit') {

            $id = (int)($_POST['id'] ?? 0);
            $nama = trim($_POST['nama'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $noHp = trim($_POST['no_hp'] ?? '');
            $password = $_POST['password'] ?? '';
            $role = $_POST['role'] ?? '';

            if ($id <= 0 || $nama === '' || $email === '') {
                throw new Exception('Data pengguna belum lengkap.');
            }

            if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
                throw new Exception('Format email tidak valid.');
            }

            if (!in_array($role, ['admin', 'pemilih'], true)) {
                throw new Exception('Role tidak valid.');
            }

            if ($password !== '' && strlen($password) < 8) {
                throw new Exception('Password minimal 8 karakter.');
            }

            // Ambil data pengguna lama
            $cekUser = mysqli_prepare($conn,
                "SELECT id, role FROM users WHERE id = ?");

            mysqli_stmt_bind_param($cekUser, "i", $id);
            mysqli_stmt_execute($cekUser);

            $userLama = mysqli_fetch_assoc(
                mysqli_stmt_get_result($cekUser)
            );

            if (!$userLama) {
                throw new Exception('Pengguna tidak ditemukan.');
            }

            // Admin tidak boleh mengubah role akunnya sendiri
            if ($id === (int)$_SESSION['id'] && $role !== 'admin') {
                throw new Exception('Role akun admin yang sedang digunakan tidak boleh diubah.');
            }

            // Cek email duplikat
            $cekEmail = mysqli_prepare($conn,
                "SELECT id FROM users WHERE email = ? AND id != ?");

            mysqli_stmt_bind_param($cekEmail, "si", $email, $id);
            mysqli_stmt_execute($cekEmail);

            if (mysqli_num_rows(mysqli_stmt_get_result($cekEmail)) > 0) {
                throw new Exception('Email sudah digunakan pengguna lain.');
            }

            if ($password !== '') {

                $hash = password_hash($password, PASSWORD_DEFAULT);

                $stmt = mysqli_prepare($conn, "
                    UPDATE users SET
                        nama = ?,
                        email = ?,
                        no_hp = ?,
                        password = ?,
                        role = ?
                    WHERE id = ?
                ");

                mysqli_stmt_bind_param(
                    $stmt,
                    "sssssi",
                    $nama,
                    $email,
                    $noHp,
                    $hash,
                    $role,
                    $id
                );

            } else {

                $stmt = mysqli_prepare($conn, "
                    UPDATE users SET
                        nama = ?,
                        email = ?,
                        no_hp = ?,
                        role = ?
                    WHERE id = ?
                ");

                mysqli_stmt_bind_param(
                    $stmt,
                    "ssssi",
                    $nama,
                    $email,
                    $noHp,
                    $role,
                    $id
                );
            }

            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception('Gagal memperbarui pengguna.');
            }

            // Perbarui session jika admin mengedit dirinya sendiri
            if ($id === (int)$_SESSION['id']) {
                $_SESSION['nama'] = $nama;
                $_SESSION['email'] = $email;
            }

            $_SESSION['flash'] = [
                'pesan' => 'Data pengguna berhasil diperbarui!',
                'jenis' => 'success'
            ];
        }

        // ============================
        // HAPUS PENGGUNA
        // ============================
        elseif ($aksi === 'hapus') {

            $id = (int)($_POST['id'] ?? 0);

            if ($id <= 0) {
                throw new Exception('ID pengguna tidak valid.');
            }

            if ($id === (int)$_SESSION['id']) {
                throw new Exception('Kamu tidak dapat menghapus akun sendiri.');
            }

            // Jangan hapus akun admin terakhir
            $cekRole = mysqli_prepare($conn,
                "SELECT role FROM users WHERE id = ?");

            mysqli_stmt_bind_param($cekRole, "i", $id);
            mysqli_stmt_execute($cekRole);

            $target = mysqli_fetch_assoc(
                mysqli_stmt_get_result($cekRole)
            );

            if (!$target) {
                throw new Exception('Pengguna tidak ditemukan.');
            }

            if ($target['role'] === 'admin') {

                $jumlahAdmin = mysqli_fetch_assoc(
                    mysqli_query($conn,
                        "SELECT COUNT(*) AS total FROM users WHERE role='admin'")
                )['total'];

                if ($jumlahAdmin <= 1) {
                    throw new Exception('Admin terakhir tidak boleh dihapus.');
                }
            }

            $stmt = mysqli_prepare($conn,
                "DELETE FROM users WHERE id = ?");

            mysqli_stmt_bind_param($stmt, "i", $id);

            if (!mysqli_stmt_execute($stmt)) {
                throw new Exception(
                    'Pengguna tidak dapat dihapus karena memiliki riwayat voting.'
                );
            }

            $_SESSION['flash'] = [
                'pesan' => 'Pengguna berhasil dihapus!',
                'jenis' => 'success'
            ];

        } else {
            throw new Exception('Aksi tidak dikenal.');
        }

    } catch (Throwable $e) {

        $_SESSION['flash'] = [
            'pesan' => $e->getMessage(),
            'jenis' => 'danger'
        ];
    }

    header("Location: pengguna.php");
    exit;
}


// ============================
// DATA EDIT
// ============================
$dataEdit = null;

if (isset($_GET['edit'])) {

    $idEdit = (int)$_GET['edit'];

    $stmt = mysqli_prepare($conn,
        "SELECT id, nama, email, no_hp, role FROM users WHERE id = ?");

    mysqli_stmt_bind_param($stmt, "i", $idEdit);
    mysqli_stmt_execute($stmt);

    $dataEdit = mysqli_fetch_assoc(
        mysqli_stmt_get_result($stmt)
    );

    if (!$dataEdit) {
        $_SESSION['flash'] = [
            'pesan' => 'Pengguna tidak ditemukan.',
            'jenis' => 'danger'
        ];

        header("Location: pengguna.php");
        exit;
    }
}


// ============================
// PENCARIAN DAN FILTER
// ============================
$keyword = trim($_GET['cari'] ?? '');
$filter = $_GET['role'] ?? '';

$sql = "
    SELECT id, nama, email, no_hp, role, created_at
    FROM users
    WHERE 1=1
";

$params = [];
$types = '';

if ($keyword !== '') {

    $sql .= " AND (nama LIKE ? OR email LIKE ? OR no_hp LIKE ?)";

    $cari = "%$keyword%";

    $params[] = $cari;
    $params[] = $cari;
    $params[] = $cari;

    $types .= 'sss';
}

if (in_array($filter, ['admin', 'pemilih'], true)) {
    $sql .= " AND role = ?";
    $params[] = $filter;
    $types .= 's';
}

$sql .= " ORDER BY id DESC";

$stmt = mysqli_prepare($conn, $sql);

if ($params) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

mysqli_stmt_execute($stmt);

$result = mysqli_stmt_get_result($stmt);


// ============================
// STATISTIK
// ============================
$totalPengguna = mysqli_fetch_assoc(
    mysqli_query($conn,
        "SELECT COUNT(*) AS total FROM users")
)['total'];

$totalAdmin = mysqli_fetch_assoc(
    mysqli_query($conn,
        "SELECT COUNT(*) AS total FROM users WHERE role='admin'")
)['total'];

$totalPemilih = mysqli_fetch_assoc(
    mysqli_query($conn,
        "SELECT COUNT(*) AS total FROM users WHERE role='pemilih'")
)['total'];

?>

<!DOCTYPE html>
<html lang="id">

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Data Pengguna | Kakang Senduk Ponorogo</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>

        :root {
            --maroon: #681d25;
            --dark: #451018;
            --gold: #e9b94e;
            --bg: #f5f6fa;
        }

        body {
            margin: 0;
            background: var(--bg);
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, var(--dark), var(--maroon));
            color: white;
            padding: 25px 18px;
            z-index: 1000;
            overflow-y: auto;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 8px 25px;
            border-bottom: 1px solid rgba(255,255,255,.15);
        }

        .brand-logo {
            width: 48px;
            height: 48px;
            background: var(--gold);
            color: var(--dark);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            font-size: 20px;
        }

        .brand h5 {
            font-size: 15px;
            font-weight: 800;
            margin: 0;
        }

        .brand small {
            font-size: 11px;
            color: #e9c7c7;
        }

        .menu-label {
            font-size: 11px;
            color: #d5a9a9;
            margin: 28px 10px 12px;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #f1dddd;
            text-decoration: none;
            padding: 12px 14px;
            border-radius: 10px;
            margin-bottom: 6px;
            font-size: 14px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: var(--gold);
            color: var(--dark);
            font-weight: 700;
        }

        .sidebar a i {
            font-size: 18px;
        }

        .main-content {
            margin-left: 260px;
            padding: 25px 30px;
        }

        .topbar {
            background: white;
            padding: 17px 23px;
            border-radius: 14px;
            margin-bottom: 25px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
        }

        .topbar h5 {
            margin: 0;
            color: var(--dark);
            font-weight: 800;
        }

        .page-title {
            font-weight: 800;
            color: var(--dark);
        }

        .stat-card,
        .content-card {
            background: white;
            border-radius: 15px;
            padding: 22px;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
            height: 100%;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 22px;
            margin-bottom: 12px;
        }

        .maroon {
            background: #f7e8e9;
            color: var(--maroon);
        }

        .gold {
            background: #fff4d7;
            color: #ad7910;
        }

        .green {
            background: #e2f5e9;
            color: #198754;
        }

        .stat-card h3 {
            font-weight: 800;
            margin: 0;
        }

        .stat-card p {
            color: #888;
            font-size: 13px;
            margin: 5px 0 0;
        }

        .btn-maroon {
            background: var(--maroon);
            color: white;
            border: none;
        }

        .btn-maroon:hover {
            background: var(--dark);
            color: white;
        }

        .form-control,
        .form-select {
            border-radius: 9px;
            padding: 10px 12px;
        }

        .form-label {
            font-size: 13px;
            font-weight: 600;
        }

        .table thead th {
            background: #faf5f5;
            color: var(--maroon);
            font-size: 12px;
            white-space: nowrap;
        }

        .table tbody td {
            font-size: 13px;
            vertical-align: middle;
        }

        .badge-admin {
            background: #f7e8e9;
            color: var(--maroon);
        }

        .badge-pemilih {
            background: #e2f5e9;
            color: #198754;
        }

        .action-btn {
            width: 33px;
            height: 33px;
            display: inline-flex;
            align-items: center;
            justify-content: center;
            border-radius: 8px;
            text-decoration: none;
            border: none;
        }

        .edit-btn {
            background: #e3efff;
            color: #0d6efd;
        }

        .delete-btn {
            background: #fce5e5;
            color: #dc3545;
        }

        @media(max-width: 900px) {

            .sidebar {
                width: 75px;
                padding: 20px 10px;
            }

            .brand {
                justify-content: center;
                padding: 0 0 20px;
            }

            .brand-text,
            .menu-label,
            .sidebar a span {
                display: none;
            }

            .sidebar a {
                justify-content: center;
                padding: 13px;
            }

            .main-content {
                margin-left: 75px;
                padding: 18px;
            }
        }

        @media(max-width: 576px) {

            .main-content {
                padding: 12px;
            }

        }

    </style>

</head>

<body>


<!-- SIDEBAR -->
<aside class="sidebar">

    <div class="brand">

        <div class="brand-logo">KS</div>

        <div class="brand-text">
            <h5>KAKANG SENDUK</h5>
            <small>ADMIN PANEL</small>
        </div>

    </div>


    <div class="menu-label">Menu Utama</div>

    <a href="dashboard.php">
        <i class="bi bi-grid-1x2-fill"></i>
        <span>Dashboard</span>
    </a>

    <a href="kontestan.php">
        <i class="bi bi-people-fill"></i>
        <span>Data Kontestan</span>
    </a>

    <a href="pengguna.php" class="active">
        <i class="bi bi-person-badge-fill"></i>
        <span>Data Pengguna</span>
    </a>


    <div class="menu-label">Pemilihan</div>

    <a href="periode.php">
        <i class="bi bi-calendar-event-fill"></i>
        <span>Periode Voting</span>
    </a>

    <a href="hasil-voting.php">
        <i class="bi bi-bar-chart-fill"></i>
        <span>Hasil Voting</span>
    </a>

    <a href="../klasemen.php">
        <i class="bi bi-trophy-fill"></i>
        <span>Klasemen</span>
    </a>


    <div class="menu-label">Lainnya</div>

    <a href="../index.php">
        <i class="bi bi-house-fill"></i>
        <span>Lihat Website</span>
    </a>

    <a href="../auth/logout.php"
       onclick="return confirm('Yakin ingin logout?')">
        <i class="bi bi-box-arrow-left"></i>
        <span>Logout</span>
    </a>

</aside>


<!-- MAIN CONTENT -->
<main class="main-content">


    <!-- TOPBAR -->
    <div class="topbar">

        <div>
            <h5>Data Pengguna</h5>
            <small class="text-muted">Manajemen akun pengguna</small>
        </div>

        <div class="text-end">

            <strong><?= e($_SESSION['nama']) ?></strong>

            <br>

            <small class="text-muted">Administrator</small>

        </div>

    </div>


    <!-- JUDUL -->
    <div class="mb-4">

        <h3 class="page-title">Data Pengguna</h3>

        <p class="text-muted">
            Kelola akun administrator dan pemilih.
        </p>

    </div>


    <!-- ALERT -->
    <?php if ($pesan): ?>

        <div class="alert alert-<?= e($jenisPesan) ?> alert-dismissible fade show">

            <?= e($pesan) ?>

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"></button>

        </div>

    <?php endif; ?>


    <!-- STATISTIK -->
    <div class="row g-3 mb-4">

        <div class="col-6 col-lg-4">

            <div class="stat-card">

                <div class="stat-icon maroon">
                    <i class="bi bi-people-fill"></i>
                </div>

                <h3><?= number_format($totalPengguna) ?></h3>

                <p>Total Pengguna</p>

            </div>

        </div>


        <div class="col-6 col-lg-4">

            <div class="stat-card">

                <div class="stat-icon gold">
                    <i class="bi bi-shield-lock-fill"></i>
                </div>

                <h3><?= number_format($totalAdmin) ?></h3>

                <p>Total Admin</p>

            </div>

        </div>


        <div class="col-6 col-lg-4">

            <div class="stat-card">

                <div class="stat-icon green">
                    <i class="bi bi-person-check-fill"></i>
                </div>

                <h3><?= number_format($totalPemilih) ?></h3>

                <p>Total Pemilih</p>

            </div>

        </div>

    </div>


    <!-- FORM TAMBAH / EDIT -->
    <div class="content-card mb-4">

        <h5 class="fw-bold mb-4" style="color:#451018">

            <i class="bi bi-<?= $dataEdit ? 'pencil-square' : 'person-plus-fill' ?> me-2"></i>

            <?= $dataEdit ? 'Edit Pengguna' : 'Tambah Pengguna' ?>

        </h5>


        <form method="POST">

            <input type="hidden"
                   name="csrf_token"
                   value="<?= e($_SESSION['csrf_token']) ?>">

            <input type="hidden"
                   name="aksi"
                   value="<?= $dataEdit ? 'edit' : 'tambah' ?>">

            <?php if ($dataEdit): ?>

                <input type="hidden"
                       name="id"
                       value="<?= (int)$dataEdit['id'] ?>">

            <?php endif; ?>


            <div class="row g-3">

                <div class="col-md-6">

                    <label class="form-label">Nama Lengkap *</label>

                    <input type="text"
                           name="nama"
                           class="form-control"
                           placeholder="Masukkan nama lengkap"
                           maxlength="100"
                           value="<?= e($dataEdit['nama'] ?? '') ?>"
                           required>

                </div>


                <div class="col-md-6">

                    <label class="form-label">Email *</label>

                    <input type="email"
                           name="email"
                           class="form-control"
                           placeholder="Masukkan email"
                           maxlength="100"
                           value="<?= e($dataEdit['email'] ?? '') ?>"
                           required>

                </div>


                <div class="col-md-6">

                    <label class="form-label">Nomor HP</label>

                    <input type="text"
                           name="no_hp"
                           class="form-control"
                           placeholder="08xxxxxxxxxx"
                           maxlength="20"
                           value="<?= e($dataEdit['no_hp'] ?? '') ?>">

                </div>


                <div class="col-md-6">

                    <label class="form-label">Role Pengguna *</label>

                    <select name="role" class="form-select" required>

                        <option value="">Pilih Role</option>

                        <option value="pemilih"
                            <?= ($dataEdit['role'] ?? '') === 'pemilih' ? 'selected' : '' ?>>
                            Pemilih
                        </option>

                        <option value="admin"
                            <?= ($dataEdit['role'] ?? '') === 'admin' ? 'selected' : '' ?>>
                            Admin
                        </option>

                    </select>

                </div>


                <div class="col-md-12">

                    <label class="form-label">

                        Password

                        <?= $dataEdit ? '(Kosongkan jika tidak ingin mengganti)' : '*' ?>

                    </label>

                    <input type="password"
                           name="password"
                           class="form-control"
                           placeholder="Minimal 8 karakter"
                           minlength="8"
                           <?= $dataEdit ? '' : 'required' ?>
                           autocomplete="new-password">

                </div>


                <div class="col-12 mt-4">

                    <button type="submit" class="btn btn-maroon px-4">

                        <i class="bi bi-save me-2"></i>

                        <?= $dataEdit ? 'Simpan Perubahan' : 'Tambah Pengguna' ?>

                    </button>

                    <?php if ($dataEdit): ?>

                        <a href="pengguna.php" class="btn btn-outline-secondary px-4">
                            Batal
                        </a>

                    <?php endif; ?>

                </div>

            </div>

        </form>

    </div>


    <!-- TABEL PENGGUNA -->
    <div class="content-card">

        <h5 class="fw-bold mb-4" style="color:#451018">

            <i class="bi bi-table me-2"></i>

            Daftar Pengguna

        </h5>


        <!-- PENCARIAN -->
        <form method="GET" class="row g-2 mb-4">

            <div class="col-md-6">

                <input type="text"
                       name="cari"
                       class="form-control"
                       placeholder="Cari nama, email, atau nomor HP..."
                       value="<?= e($keyword) ?>">

            </div>


            <div class="col-md-3">

                <select name="role" class="form-select">

                    <option value="">Semua Role</option>

                    <option value="admin"
                        <?= $filter === 'admin' ? 'selected' : '' ?>>
                        Admin
                    </option>

                    <option value="pemilih"
                        <?= $filter === 'pemilih' ? 'selected' : '' ?>>
                        Pemilih
                    </option>

                </select>

            </div>


            <div class="col-md-3 d-flex gap-2">

                <button type="submit" class="btn btn-maroon flex-fill">

                    <i class="bi bi-search me-1"></i>

                    Cari

                </button>

                <a href="pengguna.php" class="btn btn-outline-secondary">
                    Reset
                </a>

            </div>

        </form>


        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Nama Pengguna</th>
                        <th>Email</th>
                        <th>Nomor HP</th>
                        <th>Role</th>
                        <th>Tanggal Daftar</th>
                        <th>Aksi</th>
                    </tr>

                </thead>


                <tbody>

                <?php if (mysqli_num_rows($result) > 0): ?>

                    <?php $no = 1; ?>

                    <?php while ($row = mysqli_fetch_assoc($result)): ?>

                        <tr>

                            <td><?= $no++ ?></td>

                            <td>

                                <strong><?= e($row['nama']) ?></strong>

                                <?php if ((int)$row['id'] === (int)$_SESSION['id']): ?>

                                    <br>
                                    <small class="text-success">Akun Anda</small>

                                <?php endif; ?>

                            </td>


                            <td><?= e($row['email']) ?></td>


                            <td><?= e($row['no_hp'] ?: '-') ?></td>


                            <td>

                                <?php if ($row['role'] === 'admin'): ?>

                                    <span class="badge badge-admin px-3 py-2">
                                        <i class="bi bi-shield-lock-fill me-1"></i>
                                        Admin
                                    </span>

                                <?php else: ?>

                                    <span class="badge badge-pemilih px-3 py-2">
                                        <i class="bi bi-person-fill me-1"></i>
                                        Pemilih
                                    </span>

                                <?php endif; ?>

                            </td>


                            <td>

                                <?= !empty($row['created_at'])
                                    ? date('d-m-Y H:i', strtotime($row['created_at']))
                                    : '-' ?>

                            </td>


                            <td>

                                <div class="d-flex gap-2">

                                    <a href="pengguna.php?edit=<?= (int)$row['id'] ?>"
                                       class="action-btn edit-btn"
                                       title="Edit">

                                        <i class="bi bi-pencil-fill"></i>

                                    </a>


                                    <?php if ((int)$row['id'] !== (int)$_SESSION['id']): ?>

                                        <form method="POST"
                                              onsubmit="return confirm('Yakin ingin menghapus pengguna ini?')">

                                            <input type="hidden"
                                                   name="csrf_token"
                                                   value="<?= e($_SESSION['csrf_token']) ?>">

                                            <input type="hidden"
                                                   name="aksi"
                                                   value="hapus">

                                            <input type="hidden"
                                                   name="id"
                                                   value="<?= (int)$row['id'] ?>">

                                            <button type="submit"
                                                    class="action-btn delete-btn"
                                                    title="Hapus">

                                                <i class="bi bi-trash-fill"></i>

                                            </button>

                                        </form>

                                    <?php endif; ?>

                                </div>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="7" class="text-center py-5 text-muted">

                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>

                            Data pengguna tidak ditemukan.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


    <div class="text-center text-muted small py-4">

        © <?= date('Y') ?> Pemilihan Kakang Senduk Ponorogo.

    </div>

</main>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
