<?php
$halamanAktif = basename($_SERVER['PHP_SELF']);
$sidebarPrefix = $sidebarPrefix ?? '';
$sitePrefix = $sitePrefix ?? '../';
$menu = [
    ['Dashboard', 'dashboard.php', 'bi-grid-1x2-fill'],
    ['Data Kontestan', 'kontestan.php', 'bi-people-fill'],
    ['Data Pengguna', 'pengguna.php', 'bi-person-badge-fill'],
    ['Periode Voting', 'periode.php', 'bi-calendar-event-fill'],
    ['Hasil Voting', 'hasil-voting.php', 'bi-bar-chart-fill'],
    ['Klasemen', $sitePrefix . 'klasemen.php', 'bi-trophy-fill']
];
?>
<link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
<style>
    :root { --maroon: #681d25; --dark: #451018; --gold: #e9b94e; --bg: #f5f6fa; }
    body { margin: 0; background: var(--bg); font-family: 'Segoe UI', sans-serif; }
    .sidebar { width: 260px; height: 100vh; position: fixed; top: 0; left: 0; background: linear-gradient(180deg, var(--dark), var(--maroon)); color: white; padding: 25px 18px; z-index: 1000; overflow-y: auto; }
    .brand { display: flex; align-items: center; gap: 12px; padding: 0 8px 25px; border-bottom: 1px solid rgba(255,255,255,.15); }
    .brand-logo { width: 48px; height: 48px; background: var(--gold); color: var(--dark); border-radius: 14px; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 20px; }
    .brand h5 { font-size: 15px; font-weight: 800; margin: 0; }
    .brand small { font-size: 11px; color: #e9c7c7; }
    .menu-label { font-size: 11px; color: #d5a9a9; margin: 28px 10px 12px; letter-spacing: 1px; font-weight: 700; }
    .sidebar a { display: flex; align-items: center; gap: 13px; color: #f1dddd; text-decoration: none; padding: 12px 14px; border-radius: 10px; margin-bottom: 6px; font-size: 14px; }
    .sidebar a:hover, .sidebar a.active { background: var(--gold); color: var(--dark); font-weight: 700; }
    .sidebar a i { font-size: 18px; }
    .main-content { margin-left: 260px; padding: 25px 30px; min-height: 100vh; }
    @media (max-width: 768px) { .sidebar { position: relative; width: 100%; height: auto; } .main-content { margin-left: 0; padding: 18px 15px; } }
</style>
<aside class="sidebar">
    <div class="brand"><div class="brand-logo">KS</div><div><h5>KAKANG SENDUK</h5><small>ADMIN PANEL</small></div></div>
    <div class="menu-label">Menu Utama</div>
    <?php foreach ($menu as $item): $href = str_contains($item[1], 'klasemen.php') ? $item[1] : $sidebarPrefix . $item[1]; ?>
        <a href="<?= htmlspecialchars($href, ENT_QUOTES, 'UTF-8') ?>" class="<?= $halamanAktif === basename($item[1]) ? 'active' : '' ?>"><i class="bi <?= htmlspecialchars($item[2], ENT_QUOTES, 'UTF-8') ?>"></i><span><?= htmlspecialchars($item[0], ENT_QUOTES, 'UTF-8') ?></span></a>
    <?php endforeach; ?>
    <div class="menu-label">Lainnya</div>
    <a href="<?= htmlspecialchars($sitePrefix . 'index.php', ENT_QUOTES, 'UTF-8') ?>"><i class="bi bi-house-fill"></i><span>Lihat Website</span></a>
    <a href="<?= htmlspecialchars($sidebarPrefix . '../auth/logout.php', ENT_QUOTES, 'UTF-8') ?>" onclick="return confirm('Yakin ingin logout?')"><i class="bi bi-box-arrow-left"></i><span>Logout</span></a>
</aside>

