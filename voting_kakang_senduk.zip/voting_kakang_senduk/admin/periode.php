
<?php
session_start();
require_once '../config/koneksi.php';

// Cek login admin
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

$pesan = '';
$error = '';

// Token CSRF
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

// Tambah periode
if (isset($_POST['tambah'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die('Permintaan tidak valid.');
    }

    $nama = trim($_POST['nama_periode']);
    $mulai = $_POST['tanggal_mulai'];
    $selesai = $_POST['tanggal_selesai'];
    $status = $_POST['status'];

    if ($nama === '' || $mulai === '' || $selesai === '') {
        $error = 'Semua data wajib diisi.';
    } elseif (strtotime($selesai) <= strtotime($mulai)) {
        $error = 'Tanggal selesai harus setelah tanggal mulai.';
    } elseif (!in_array($status, ['Aktif', 'Nonaktif'], true)) {
        $error = 'Status tidak valid.';
    } else {
        try {
            $conn->begin_transaction();

            if ($status === 'Aktif') {
                $conn->query("UPDATE periode_voting SET status = 'Nonaktif'");
            }

            $stmt = $conn->prepare(
                "INSERT INTO periode_voting
                (nama_periode, tanggal_mulai, tanggal_selesai, status)
                VALUES (?, ?, ?, ?)"
            );
            $stmt->bind_param("ssss", $nama, $mulai, $selesai, $status);
            $stmt->execute();

            $conn->commit();
            $pesan = 'Periode voting berhasil ditambahkan.';
        } catch (Throwable $e) {
            $conn->rollback();
            $error = 'Gagal menambahkan periode voting.';
        }
    }
}

// Edit periode
if (isset($_POST['edit'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die('Permintaan tidak valid.');
    }

    $id = (int) $_POST['id'];
    $nama = trim($_POST['nama_periode']);
    $mulai = $_POST['tanggal_mulai'];
    $selesai = $_POST['tanggal_selesai'];
    $status = $_POST['status'];

    if ($id <= 0 || $nama === '' || $mulai === '' || $selesai === '') {
        $error = 'Data periode belum lengkap.';
    } elseif (strtotime($selesai) <= strtotime($mulai)) {
        $error = 'Tanggal selesai harus setelah tanggal mulai.';
    } elseif (!in_array($status, ['Aktif', 'Nonaktif'], true)) {
        $error = 'Status tidak valid.';
    } else {
        try {
            $conn->begin_transaction();

            if ($status === 'Aktif') {
                $stmt = $conn->prepare(
                    "UPDATE periode_voting SET status = 'Nonaktif' WHERE id != ?"
                );
                $stmt->bind_param("i", $id);
                $stmt->execute();
            }

            $stmt = $conn->prepare(
                "UPDATE periode_voting
                 SET nama_periode = ?, tanggal_mulai = ?,
                     tanggal_selesai = ?, status = ?
                 WHERE id = ?"
            );
            $stmt->bind_param("ssssi", $nama, $mulai, $selesai, $status, $id);
            $stmt->execute();

            $conn->commit();
            $pesan = 'Periode voting berhasil diperbarui.';
        } catch (Throwable $e) {
            $conn->rollback();
            $error = 'Gagal memperbarui periode voting.';
        }
    }
}

// Hapus periode
if (isset($_POST['hapus'])) {
    if (!hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'] ?? '')) {
        die('Permintaan tidak valid.');
    }

    $id = (int) $_POST['id'];

    if ($id > 0) {
        $stmt = $conn->prepare("DELETE FROM periode_voting WHERE id = ?");
        $stmt->bind_param("i", $id);

        if ($stmt->execute()) {
            $pesan = 'Periode voting berhasil dihapus.';
        } else {
            $error = 'Gagal menghapus periode voting.';
        }
    }
}

// Ambil data periode
$result = $conn->query(
    "SELECT * FROM periode_voting ORDER BY id DESC"
);

$periode = [];
while ($row = $result->fetch_assoc()) {
    $periode[] = $row;
}

// Data untuk form edit
$editData = null;
if (isset($_GET['edit'])) {
    $idEdit = (int) $_GET['edit'];

    $stmt = $conn->prepare("SELECT * FROM periode_voting WHERE id = ?");
    $stmt->bind_param("i", $idEdit);
    $stmt->execute();

    $editData = $stmt->get_result()->fetch_assoc();
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Periode Voting</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
<?php $sidebarPrefix = ''; $sitePrefix = '../'; include 'sidebar.php'; ?>
<main class="main-content">
<div class="container-fluid py-2">
    <div class="mb-4">
        <h3>Manajemen Periode Voting</h3>
        <p class="text-muted">Kelola jadwal pelaksanaan pemilihan Kakang Senduk.</p>
    </div>

    <?php if ($pesan): ?>
        <div class="alert alert-success"><?= e($pesan) ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="alert alert-danger"><?= e($error) ?></div>
    <?php endif; ?>

    <div class="card shadow-sm mb-4">
        <div class="card-header bg-white">
            <strong><?= $editData ? 'Edit Periode' : 'Tambah Periode' ?></strong>
        </div>

        <div class="card-body">
            <form method="POST">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">

                <?php if ($editData): ?>
                    <input type="hidden" name="id" value="<?= (int) $editData['id'] ?>">
                <?php endif; ?>

                <div class="mb-3">
                    <label class="form-label">Nama Periode</label>
                    <input type="text" name="nama_periode" class="form-control"
                           placeholder="Contoh: Pemilihan Kakang Senduk 2026"
                           value="<?= e($editData['nama_periode'] ?? '') ?>" required>
                </div>

                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tanggal Mulai</label>
                        <input type="datetime-local" name="tanggal_mulai"
                               class="form-control"
                               value="<?= $editData ? e(date('Y-m-d\TH:i', strtotime($editData['tanggal_mulai']))) : '' ?>"
                               required>
                    </div>

                    <div class="col-md-6 mb-3">
                        <label class="form-label">Tanggal Selesai</label>
                        <input type="datetime-local" name="tanggal_selesai"
                               class="form-control"
                               value="<?= $editData ? e(date('Y-m-d\TH:i', strtotime($editData['tanggal_selesai']))) : '' ?>"
                               required>
                    </div>
                </div>

                <div class="mb-3">
                    <label class="form-label">Status</label>
                    <select name="status" class="form-select" required>
                        <option value="Nonaktif"
                            <?= ($editData['status'] ?? '') === 'Nonaktif' ? 'selected' : '' ?>>
                            Nonaktif
                        </option>
                        <option value="Aktif"
                            <?= ($editData['status'] ?? '') === 'Aktif' ? 'selected' : '' ?>>
                            Aktif
                        </option>
                    </select>
                </div>

                <button type="submit"
                        name="<?= $editData ? 'edit' : 'tambah' ?>"
                        class="btn btn-primary">
                    <?= $editData ? 'Simpan Perubahan' : 'Tambah Periode' ?>
                </button>

                <?php if ($editData): ?>
                    <a href="periode.php" class="btn btn-secondary">Batal</a>
                <?php endif; ?>
            </form>
        </div>
    </div>

    <div class="card shadow-sm">
        <div class="card-header bg-white">
            <strong>Daftar Periode Voting</strong>
        </div>

        <div class="table-responsive">
            <table class="table table-bordered table-hover mb-0 align-middle">
                <thead class="table-dark">
                    <tr>
                        <th>No</th>
                        <th>Nama Periode</th>
                        <th>Tanggal Mulai</th>
                        <th>Tanggal Selesai</th>
                        <th>Status</th>
                        <th width="160">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (count($periode) > 0): ?>
                        <?php foreach ($periode as $i => $p): ?>
                            <tr>
                                <td><?= $i + 1 ?></td>
                                <td><?= e($p['nama_periode']) ?></td>
                                <td><?= e(date('d-m-Y H:i', strtotime($p['tanggal_mulai']))) ?></td>
                                <td><?= e(date('d-m-Y H:i', strtotime($p['tanggal_selesai']))) ?></td>
                                <td>
                                    <?php if ($p['status'] === 'Aktif'): ?>
                                        <span class="badge bg-success">Aktif</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">Nonaktif</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="periode.php?edit=<?= (int) $p['id'] ?>"
                                       class="btn btn-warning btn-sm">Edit</a>

                                    <form method="POST" class="d-inline"
                                          onsubmit="return confirm('Yakin ingin menghapus periode ini?')">
                                        <input type="hidden" name="csrf_token"
                                               value="<?= e($_SESSION['csrf_token']) ?>">
                                        <input type="hidden" name="id"
                                               value="<?= (int) $p['id'] ?>">
                                        <button type="submit" name="hapus"
                                                class="btn btn-danger btn-sm">
                                            Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="6" class="text-center text-muted">
                                Belum ada periode voting.
                            </td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <a href="dashboard.php" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
</div>
</main>

</body>
</html>
