
<?php
session_start();
require_once '../config/koneksi.php';

// Proteksi halaman admin
if (!isset($_SESSION['id']) || $_SESSION['role'] !== 'admin') {
    header("Location: ../auth/login.php");
    exit;
}

// Folder upload
$folderFoto = '../assets/img/kontestan/';

if (!is_dir($folderFoto)) {
    mkdir($folderFoto, 0755, true);
}

// CSRF token
if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$pesan = '';
$jenisPesan = 'success';

// Fungsi keamanan output
function e($value) {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function urlFotoKontestan($foto) {
    $namaFile = basename(trim((string)$foto));
    if ($namaFile === '') return null;
    if (is_file(__DIR__ . '/../assets/img/kontestan/' . $namaFile)) {
        return '../assets/img/kontestan/' . rawurlencode($namaFile);
    }
    if (is_file(__DIR__ . '/../uploads/' . $namaFile)) {
        return '../uploads/' . rawurlencode($namaFile);
    }
    return null;
}

// Flash message
if (isset($_SESSION['flash'])) {
    $pesan = $_SESSION['flash']['pesan'];
    $jenisPesan = $_SESSION['flash']['jenis'];
    unset($_SESSION['flash']);
}

// Fungsi upload foto
function uploadFoto($folder) {
    if (!isset($_FILES['foto']) || $_FILES['foto']['error'] === UPLOAD_ERR_NO_FILE) {
        return null;
    }

    if ($_FILES['foto']['error'] !== UPLOAD_ERR_OK) {
        throw new Exception('Terjadi kesalahan saat mengupload foto.');
    }

    if ($_FILES['foto']['size'] > 2 * 1024 * 1024) {
        throw new Exception('Ukuran foto maksimal 2 MB.');
    }

    $finfo = finfo_open(FILEINFO_MIME_TYPE);
    $mime = finfo_file($finfo, $_FILES['foto']['tmp_name']);
    finfo_close($finfo);

    $ekstensi = [
        'image/jpeg' => 'jpg',
        'image/png' => 'png',
        'image/webp' => 'webp'
    ];

    if (!isset($ekstensi[$mime])) {
        throw new Exception('Format foto harus JPG, PNG, atau WEBP.');
    }

    $namaFile = bin2hex(random_bytes(16)) . '.' . $ekstensi[$mime];

    if (!move_uploaded_file(
        $_FILES['foto']['tmp_name'],
        $folder . $namaFile
    )) {
        throw new Exception('Gagal menyimpan foto.');
    }

    return $namaFile;
}

// Fungsi menghapus foto
function hapusFoto($folder, $namaFoto) {
    if (
        !empty($namaFoto) &&
        basename($namaFoto) === $namaFoto &&
        is_file($folder . $namaFoto)
    ) {
        unlink($folder . $namaFoto);
    }
}

// PROSES TAMBAH, EDIT, HAPUS
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        if (
            !hash_equals(
                $_SESSION['csrf_token'],
                $_POST['csrf_token'] ?? ''
            )
        ) {
            throw new Exception('Permintaan tidak valid. Silakan refresh halaman.');
        }

        $aksi = $_POST['aksi'] ?? '';

        // =========================
        // TAMBAH DATA
        // =========================
        if ($aksi === 'tambah') {

            $nomor = trim($_POST['nomor_peserta'] ?? '');
            $nama = trim($_POST['nama'] ?? '');
            $kategori = $_POST['kategori'] ?? '';
            $tempatLahir = trim($_POST['tempat_lahir'] ?? '');
            $tanggalLahir = $_POST['tanggal_lahir'] ?: null;
            $asal = trim($_POST['asal_instansi'] ?? '');
            $visi = trim($_POST['visi'] ?? '');
            $misi = trim($_POST['misi'] ?? '');
            $prestasi = trim($_POST['prestasi'] ?? '');
            $deskripsi = trim($_POST['deskripsi'] ?? '');

            if ($nomor === '' || $nama === '' || $kategori === '') {
                throw new Exception('Nomor peserta, nama, dan kategori wajib diisi.');
            }

            if (!in_array($kategori, ['Kakang', 'Senduk'], true)) {
                throw new Exception('Kategori tidak valid.');
            }

            // Cek nomor peserta
            $cek = mysqli_prepare($conn,
                "SELECT id FROM kontestan WHERE nomor_peserta = ?");

            mysqli_stmt_bind_param($cek, "s", $nomor);
            mysqli_stmt_execute($cek);
            $hasilCek = mysqli_stmt_get_result($cek);

            if (mysqli_num_rows($hasilCek) > 0) {
                throw new Exception('Nomor peserta sudah digunakan.');
            }

            // Upload foto
            $foto = uploadFoto($folderFoto);

            $stmt = mysqli_prepare($conn, "
                INSERT INTO kontestan
                (
                    nomor_peserta,
                    nama,
                    kategori,
                    foto,
                    tempat_lahir,
                    tanggal_lahir,
                    asal_instansi,
                    visi,
                    misi,
                    prestasi,
                    deskripsi
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ");

            mysqli_stmt_bind_param(
                $stmt,
                "sssssssssss",
                $nomor,
                $nama,
                $kategori,
                $foto,
                $tempatLahir,
                $tanggalLahir,
                $asal,
                $visi,
                $misi,
                $prestasi,
                $deskripsi
            );

            if (!mysqli_stmt_execute($stmt)) {
                if ($foto) hapusFoto($folderFoto, $foto);
                throw new Exception('Gagal menambahkan kontestan.');
            }

            $_SESSION['flash'] = [
                'pesan' => 'Kontestan berhasil ditambahkan!',
                'jenis' => 'success'
            ];

        }

        // =========================
        // EDIT DATA
        // =========================
        elseif ($aksi === 'edit') {

            $id = (int)($_POST['id'] ?? 0);

            $nomor = trim($_POST['nomor_peserta'] ?? '');
            $nama = trim($_POST['nama'] ?? '');
            $kategori = $_POST['kategori'] ?? '';
            $tempatLahir = trim($_POST['tempat_lahir'] ?? '');
            $tanggalLahir = $_POST['tanggal_lahir'] ?: null;
            $asal = trim($_POST['asal_instansi'] ?? '');
            $visi = trim($_POST['visi'] ?? '');
            $misi = trim($_POST['misi'] ?? '');
            $prestasi = trim($_POST['prestasi'] ?? '');
            $deskripsi = trim($_POST['deskripsi'] ?? '');

            if ($id <= 0 || $nomor === '' || $nama === '' || $kategori === '') {
                throw new Exception('Data kontestan belum lengkap.');
            }

            if (!in_array($kategori, ['Kakang', 'Senduk'], true)) {
                throw new Exception('Kategori tidak valid.');
            }

            // Ambil data lama
            $stmtLama = mysqli_prepare($conn,
                "SELECT foto FROM kontestan WHERE id = ?");

            mysqli_stmt_bind_param($stmtLama, "i", $id);
            mysqli_stmt_execute($stmtLama);
            $dataLama = mysqli_fetch_assoc(mysqli_stmt_get_result($stmtLama));

            if (!$dataLama) {
                throw new Exception('Data kontestan tidak ditemukan.');
            }

            // Cek nomor peserta
            $cek = mysqli_prepare($conn,
                "SELECT id FROM kontestan
                 WHERE nomor_peserta = ? AND id != ?");

            mysqli_stmt_bind_param($cek, "si", $nomor, $id);
            mysqli_stmt_execute($cek);

            if (mysqli_num_rows(mysqli_stmt_get_result($cek)) > 0) {
                throw new Exception('Nomor peserta sudah digunakan.');
            }

            // Foto lama tetap digunakan jika tidak upload foto baru
            $foto = $dataLama['foto'];
            $fotoBaru = uploadFoto($folderFoto);

            if ($fotoBaru !== null) {
                $foto = $fotoBaru;
            }

            $stmt = mysqli_prepare($conn, "
                UPDATE kontestan SET
                    nomor_peserta = ?,
                    nama = ?,
                    kategori = ?,
                    foto = ?,
                    tempat_lahir = ?,
                    tanggal_lahir = ?,
                    asal_instansi = ?,
                    visi = ?,
                    misi = ?,
                    prestasi = ?,
                    deskripsi = ?
                WHERE id = ?
            ");

            mysqli_stmt_bind_param(
                $stmt,
                "sssssssssssi",
                $nomor,
                $nama,
                $kategori,
                $foto,
                $tempatLahir,
                $tanggalLahir,
                $asal,
                $visi,
                $misi,
                $prestasi,
                $deskripsi,
                $id
            );

            if (!mysqli_stmt_execute($stmt)) {
                if ($fotoBaru) hapusFoto($folderFoto, $fotoBaru);
                throw new Exception('Gagal mengubah data kontestan.');
            }

            if ($fotoBaru) {
                hapusFoto($folderFoto, $dataLama['foto']);
            }

            $_SESSION['flash'] = [
                'pesan' => 'Data kontestan berhasil diperbarui!',
                'jenis' => 'success'
            ];

        }

        // =========================
        // HAPUS DATA
        // =========================
        elseif ($aksi === 'hapus') {

            $id = (int)($_POST['id'] ?? 0);

            $stmt = mysqli_prepare($conn,
                "SELECT foto FROM kontestan WHERE id = ?");

            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);

            $data = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

            if (!$data) {
                throw new Exception('Kontestan tidak ditemukan.');
            }

            $hapus = mysqli_prepare($conn,
                "DELETE FROM kontestan WHERE id = ?");

            mysqli_stmt_bind_param($hapus, "i", $id);

            if (!mysqli_stmt_execute($hapus)) {
                throw new Exception(
                    'Kontestan tidak dapat dihapus karena sudah memiliki suara voting.'
                );
            }

            hapusFoto($folderFoto, $data['foto']);

            $_SESSION['flash'] = [
                'pesan' => 'Kontestan berhasil dihapus!',
                'jenis' => 'success'
            ];

        } else {
            throw new Exception('Aksi tidak dikenali.');
        }

    } catch (Throwable $e) {

        $_SESSION['flash'] = [
            'pesan' => $e->getMessage(),
            'jenis' => 'danger'
        ];
    }

    header("Location: kontestan.php");
    exit;
}


// =========================
// DATA EDIT
// =========================
$dataEdit = null;

if (isset($_GET['edit'])) {

    $idEdit = (int)$_GET['edit'];

    $stmt = mysqli_prepare($conn,
        "SELECT * FROM kontestan WHERE id = ?");

    mysqli_stmt_bind_param($stmt, "i", $idEdit);
    mysqli_stmt_execute($stmt);

    $dataEdit = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

    if (!$dataEdit) {
        $_SESSION['flash'] = [
            'pesan' => 'Data kontestan tidak ditemukan.',
            'jenis' => 'danger'
        ];

        header("Location: kontestan.php");
        exit;
    }
}


// =========================
// PENCARIAN DAN FILTER
// =========================
$keyword = trim($_GET['cari'] ?? '');
$filter = $_GET['kategori'] ?? '';

$sql = "
    SELECT
        k.*,
        COUNT(v.id) AS jumlah_suara
    FROM kontestan k
    LEFT JOIN voting v ON k.id = v.kontestan_id
    WHERE 1=1
";

$params = [];
$types = '';

if ($keyword !== '') {
    $sql .= " AND (k.nama LIKE ? OR k.nomor_peserta LIKE ?)";
    $cari = "%$keyword%";
    $params[] = $cari;
    $params[] = $cari;
    $types .= 'ss';
}

if (in_array($filter, ['Kakang', 'Senduk'], true)) {
    $sql .= " AND k.kategori = ?";
    $params[] = $filter;
    $types .= 's';
}

$sql .= "
    GROUP BY k.id
    ORDER BY k.kategori ASC, k.nomor_peserta ASC
";

$stmt = mysqli_prepare($conn, $sql);

if ($params) {
    mysqli_stmt_bind_param($stmt, $types, ...$params);
}

mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);


// Statistik
$total = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM kontestan")
)['total'];

$kakang = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM kontestan WHERE kategori='Kakang'")
)['total'];

$senduk = mysqli_fetch_assoc(
    mysqli_query($conn, "SELECT COUNT(*) AS total FROM kontestan WHERE kategori='Senduk'")
)['total'];

?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Data Kontestan | Kakang Senduk Ponorogo</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">

    <style>
        :root {
            --maroon: #681d25;
            --dark: #451018;
            --gold: #e9b94e;
            --bg: #f5f6fa;
        }

        body {
            margin: 0;
            background: var(--bg);
            font-family: 'Segoe UI', sans-serif;
        }

        .sidebar {
            width: 260px;
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            background: linear-gradient(180deg, var(--dark), var(--maroon));
            color: white;
            padding: 25px 18px;
            z-index: 1000;
        }

        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 0 8px 25px;
            border-bottom: 1px solid rgba(255,255,255,.15);
        }

        .brand-logo {
            width: 48px;
            height: 48px;
            background: var(--gold);
            color: var(--dark);
            border-radius: 14px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 900;
            font-size: 20px;
        }

        .brand h5 {
            font-size: 15px;
            font-weight: 800;
            margin: 0;
        }

        .brand small {
            font-size: 11px;
            color: #e9c7c7;
        }

        .menu-label {
            font-size: 11px;
            color: #d5a9a9;
            margin: 28px 10px 12px;
            letter-spacing: 1px;
            font-weight: 700;
        }

        .sidebar a {
            display: flex;
            align-items: center;
            gap: 13px;
            color: #f1dddd;
            text-decoration: none;
            padding: 12px 14px;
            border-radius: 10px;
            margin-bottom: 6px;
            font-size: 14px;
        }

        .sidebar a:hover,
        .sidebar a.active {
            background: var(--gold);
            color: var(--dark);
            font-weight: 700;
        }

        .sidebar a i {
            font-size: 18px;
        }

        .main-content {
            margin-left: 260px;
            padding: 25px 30px;
        }

        .topbar {
            background: white;
            padding: 17px 23px;
            border-radius: 14px;
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
        }

        .topbar h5 {
            margin: 0;
            color: var(--dark);
            font-weight: 800;
        }

        .page-title {
            font-weight: 800;
            color: var(--dark);
        }

        .stat-card,
        .content-card {
            background: white;
            border-radius: 15px;
            padding: 22px;
            box-shadow: 0 3px 15px rgba(0,0,0,.04);
            height: 100%;
        }

        .stat-icon {
            width: 45px;
            height: 45px;
            border-radius: 12px;
            display: flex;
            justify-content: center;
            align-items: center;
            font-size: 22px;
            margin-bottom: 12px;
        }

        .maroon {
            background: #f7e8e9;
            color: var(--maroon);
        }

        .gold {
            background: #fff4d7;
            color: #ad7910;
        }

        .green {
            background: #e2f5e9;
            color: #198754;
        }

        .stat-card h3 {
            font-weight: 800;
            margin: 0;
        }

        .stat-card p {
            color: #888;
            font-size: 13px;
            margin: 5px 0 0;
        }

        .btn-maroon {
            background: var(--maroon);
            color: white;
            border: none;
        }

        .btn-maroon:hover {
            background: var(--dark);
            color: white;
        }

        .form-control,
        .form-select {
            border-radius: 9px;
            padding: 10px 12px;
        }

        .form-label {
            font-size: 13px;
            font-weight: 600;
        }

        .participant-img {
            width: 55px;
            height: 55px;
            object-fit: cover;
            border-radius: 12px;
            background: #eee;
        }

        .table thead th {
            background: #faf5f5;
            color: var(--maroon);
            font-size: 12px;
            white-space: nowrap;
        }

        .table tbody td {
            font-size: 13px;
            vertical-align: middle;
        }

        .badge-kakang {
            background: #f7e8e9;
            color: var(--maroon);
        }

        .badge-senduk {
            background: #fff4d7;
            color: #946b13;
        }

        .action-btn {
            width: 32px;
            height: 32px;
            display: inline-flex;
            justify-content: center;
            align-items: center;
            border-radius: 8px;
            text-decoration: none;
            border: none;
        }

        .edit-btn {
            background: #e3efff;
            color: #0d6efd;
        }

        .delete-btn {
            background: #fce5e5;
            color: #dc3545;
        }

        @media(max-width: 900px) {
            .sidebar {
                width: 75px;
                padding: 20px 10px;
            }

            .brand {
                justify-content: center;
                padding: 0 0 20px;
            }

            .brand-text,
            .menu-label,
            .sidebar a span {
                display: none;
            }

            .sidebar a {
                justify-content: center;
                padding: 13px;
            }

            .main-content {
                margin-left: 75px;
                padding: 18px;
            }
        }

        @media(max-width: 576px) {
            .main-content {
                padding: 12px;
            }
        }
    </style>
</head>

<body>

<!-- SIDEBAR -->
<aside class="sidebar">

    <div class="brand">
        <div class="brand-logo">KS</div>

        <div class="brand-text">
            <h5>KAKANG SENDUK</h5>
            <small>ADMIN PANEL</small>
        </div>
    </div>

    <div class="menu-label">Menu Utama</div>

    <a href="dashboard.php">
        <i class="bi bi-grid-1x2-fill"></i>
        <span>Dashboard</span>
    </a>

    <a href="kontestan.php" class="active">
        <i class="bi bi-people-fill"></i>
        <span>Data Kontestan</span>
    </a>

    <a href="pengguna.php">
        <i class="bi bi-person-badge-fill"></i>
        <span>Data Pengguna</span>
    </a>

    <div class="menu-label">Pemilihan</div>

    <a href="periode.php">
        <i class="bi bi-calendar-event-fill"></i>
        <span>Periode Voting</span>
    </a>

    <a href="hasil-voting.php">
        <i class="bi bi-bar-chart-fill"></i>
        <span>Hasil Voting</span>
    </a>

    <a href="../klasemen.php">
        <i class="bi bi-trophy-fill"></i>
        <span>Klasemen</span>
    </a>

    <div class="menu-label">Lainnya</div>

    <a href="../index.php">
        <i class="bi bi-house-fill"></i>
        <span>Lihat Website</span>
    </a>

    <a href="../auth/logout.php"
       onclick="return confirm('Yakin ingin logout?')">
        <i class="bi bi-box-arrow-left"></i>
        <span>Logout</span>
    </a>

</aside>


<!-- KONTEN UTAMA -->
<main class="main-content">

    <!-- TOPBAR -->
    <div class="topbar">

        <div>
            <h5>Data Kontestan</h5>
            <small class="text-muted">Manajemen data peserta pemilihan</small>
        </div>

        <div class="text-end">
            <strong><?= e($_SESSION['nama']) ?></strong>
            <br>
            <small class="text-muted">Administrator</small>
        </div>

    </div>


    <!-- JUDUL -->
    <div class="mb-4">

        <h3 class="page-title">Data Kontestan</h3>

        <p class="text-muted">
            Kelola data Kakang dan Senduk Ponorogo.
        </p>

    </div>


    <!-- NOTIFIKASI -->
    <?php if ($pesan): ?>

        <div class="alert alert-<?= e($jenisPesan) ?> alert-dismissible fade show">

            <?= e($pesan) ?>

            <button type="button"
                    class="btn-close"
                    data-bs-dismiss="alert"></button>

        </div>

    <?php endif; ?>


    <!-- STATISTIK -->
    <div class="row g-3 mb-4">

        <div class="col-6 col-lg-4">

            <div class="stat-card">

                <div class="stat-icon maroon">
                    <i class="bi bi-people-fill"></i>
                </div>

                <h3><?= number_format($total) ?></h3>

                <p>Total Kontestan</p>

            </div>

        </div>

        <div class="col-6 col-lg-4">

            <div class="stat-card">

                <div class="stat-icon gold">
                    <i class="bi bi-person-fill"></i>
                </div>

                <h3><?= number_format($kakang) ?></h3>

                <p>Kontestan Kakang</p>

            </div>

        </div>

        <div class="col-6 col-lg-4">

            <div class="stat-card">

                <div class="stat-icon green">
                    <i class="bi bi-person-fill"></i>
                </div>

                <h3><?= number_format($senduk) ?></h3>

                <p>Kontestan Senduk</p>

            </div>

        </div>

    </div>


    <!-- FORM TAMBAH / EDIT -->
    <div class="content-card mb-4">

        <div class="d-flex justify-content-between align-items-center mb-4">

            <h5 class="fw-bold mb-0" style="color:#451018">

                <i class="bi bi-<?= $dataEdit ? 'pencil-square' : 'person-plus-fill' ?> me-2"></i>

                <?= $dataEdit ? 'Edit Kontestan' : 'Tambah Kontestan' ?>

            </h5>

            <?php if ($dataEdit): ?>

                <a href="kontestan.php" class="btn btn-sm btn-outline-secondary">
                    <i class="bi bi-x-circle me-1"></i>
                    Batal Edit
                </a>

            <?php endif; ?>

        </div>


        <form method="POST" enctype="multipart/form-data">

            <input type="hidden"
                   name="csrf_token"
                   value="<?= e($_SESSION['csrf_token']) ?>">

            <input type="hidden"
                   name="aksi"
                   value="<?= $dataEdit ? 'edit' : 'tambah' ?>">

            <?php if ($dataEdit): ?>

                <input type="hidden"
                       name="id"
                       value="<?= e($dataEdit['id']) ?>">

            <?php endif; ?>


            <div class="row g-3">

                <div class="col-md-4">

                    <label class="form-label">Nomor Peserta *</label>

                    <input type="text"
                           name="nomor_peserta"
                           class="form-control"
                           placeholder="Contoh: KKS-001"
                           maxlength="10"
                           value="<?= e($dataEdit['nomor_peserta'] ?? '') ?>"
                           required>

                </div>


                <div class="col-md-4">

                    <label class="form-label">Nama Lengkap *</label>

                    <input type="text"
                           name="nama"
                           class="form-control"
                           placeholder="Nama lengkap kontestan"
                           maxlength="100"
                           value="<?= e($dataEdit['nama'] ?? '') ?>"
                           required>

                </div>


                <div class="col-md-4">

                    <label class="form-label">Kategori *</label>

                    <select name="kategori" class="form-select" required>

                        <option value="">Pilih Kategori</option>

                        <option value="Kakang"
                            <?= ($dataEdit['kategori'] ?? '') === 'Kakang' ? 'selected' : '' ?>>
                            Kakang
                        </option>

                        <option value="Senduk"
                            <?= ($dataEdit['kategori'] ?? '') === 'Senduk' ? 'selected' : '' ?>>
                            Senduk
                        </option>

                    </select>

                </div>


                <div class="col-md-6">

                    <label class="form-label">Tempat Lahir</label>

                    <input type="text"
                           name="tempat_lahir"
                           class="form-control"
                           value="<?= e($dataEdit['tempat_lahir'] ?? '') ?>"
                           placeholder="Contoh: Ponorogo">

                </div>


                <div class="col-md-6">

                    <label class="form-label">Tanggal Lahir</label>

                    <input type="date"
                           name="tanggal_lahir"
                           class="form-control"
                           value="<?= e($dataEdit['tanggal_lahir'] ?? '') ?>">

                </div>


                <div class="col-md-12">

                    <label class="form-label">Asal Sekolah / Instansi</label>

                    <input type="text"
                           name="asal_instansi"
                           class="form-control"
                           placeholder="Nama sekolah atau instansi"
                           maxlength="150"
                           value="<?= e($dataEdit['asal_instansi'] ?? '') ?>">

                </div>


                <div class="col-md-6">

                    <label class="form-label">Visi</label>

                    <textarea name="visi"
                              class="form-control"
                              rows="3"
                              placeholder="Masukkan visi kontestan"><?= e($dataEdit['visi'] ?? '') ?></textarea>

                </div>


                <div class="col-md-6">

                    <label class="form-label">Misi</label>

                    <textarea name="misi"
                              class="form-control"
                              rows="3"
                              placeholder="Masukkan misi kontestan"><?= e($dataEdit['misi'] ?? '') ?></textarea>

                </div>


                <div class="col-md-12">

                    <label class="form-label">Prestasi</label>

                    <textarea name="prestasi"
                              class="form-control"
                              rows="3"
                              placeholder="Masukkan prestasi kontestan"><?= e($dataEdit['prestasi'] ?? '') ?></textarea>

                </div>


                <div class="col-md-12">

                    <label class="form-label">Deskripsi Profil</label>

                    <textarea name="deskripsi"
                              class="form-control"
                              rows="4"
                              placeholder="Ceritakan profil singkat kontestan"><?= e($dataEdit['deskripsi'] ?? '') ?></textarea>

                </div>


                <div class="col-md-12">

                    <label class="form-label">Foto Kontestan</label>

                    <input type="file"
                           name="foto"
                           class="form-control"
                           accept=".jpg,.jpeg,.png,.webp">

                    <small class="text-muted">
                        Format JPG, PNG, WEBP. Maksimal 2 MB.
                        <?= $dataEdit ? 'Kosongkan jika tidak ingin mengganti foto.' : '' ?>
                    </small>

                    <?php if ($fotoUrl = urlFotoKontestan($dataEdit['foto'] ?? '')): ?>

                        <div class="mt-3">

                            <p class="small fw-bold mb-2">Foto saat ini:</p>

                            <img src="<?= e($fotoUrl) ?>"
                                 class="participant-img"
                                 alt="Foto kontestan">

                        </div>

                    <?php endif; ?>

                </div>


                <div class="col-12 mt-4">

                    <button type="submit" class="btn btn-maroon px-4">

                        <i class="bi bi-<?= $dataEdit ? 'save' : 'plus-circle' ?> me-2"></i>

                        <?= $dataEdit ? 'Simpan Perubahan' : 'Tambah Kontestan' ?>

                    </button>

                    <?php if ($dataEdit): ?>

                        <a href="kontestan.php" class="btn btn-outline-secondary px-4">
                            Batal
                        </a>

                    <?php endif; ?>

                </div>

            </div>

        </form>

    </div>


    <!-- TABEL DATA -->
    <div class="content-card">

        <div class="d-flex justify-content-between align-items-center flex-wrap gap-3 mb-4">

            <h5 class="fw-bold mb-0" style="color:#451018">
                <i class="bi bi-table me-2"></i>
                Daftar Kontestan
            </h5>

        </div>


        <!-- PENCARIAN -->
        <form method="GET" class="row g-2 mb-4">

            <div class="col-md-6">

                <input type="text"
                       name="cari"
                       class="form-control"
                       placeholder="Cari nama atau nomor peserta..."
                       value="<?= e($keyword) ?>">

            </div>

            <div class="col-md-3">

                <select name="kategori" class="form-select">

                    <option value="">Semua Kategori</option>

                    <option value="Kakang"
                        <?= $filter === 'Kakang' ? 'selected' : '' ?>>
                        Kakang
                    </option>

                    <option value="Senduk"
                        <?= $filter === 'Senduk' ? 'selected' : '' ?>>
                        Senduk
                    </option>

                </select>

            </div>

            <div class="col-md-3 d-flex gap-2">

                <button type="submit" class="btn btn-maroon flex-fill">
                    <i class="bi bi-search me-1"></i>
                    Cari
                </button>

                <a href="kontestan.php" class="btn btn-outline-secondary">
                    Reset
                </a>

            </div>

        </form>


        <div class="table-responsive">

            <table class="table table-hover align-middle">

                <thead>

                    <tr>
                        <th>No</th>
                        <th>Foto</th>
                        <th>Nomor</th>
                        <th>Nama Kontestan</th>
                        <th>Kategori</th>
                        <th>Asal Instansi</th>
                        <th>Suara</th>
                        <th>Aksi</th>
                    </tr>

                </thead>

                <tbody>

                <?php if (mysqli_num_rows($result) > 0): ?>

                    <?php $no = 1; ?>

                    <?php while ($row = mysqli_fetch_assoc($result)): ?>

                        <tr>

                            <td><?= $no++ ?></td>

                            <td>

                                <?php if ($fotoUrl = urlFotoKontestan($row['foto'])): ?>

                                    <img src="<?= e($fotoUrl) ?>"
                                         class="participant-img"
                                         alt="Foto kontestan">

                                <?php else: ?>

                                    <div class="participant-img d-flex align-items-center justify-content-center">
                                        <i class="bi bi-person fs-3 text-muted"></i>
                                    </div>

                                <?php endif; ?>

                            </td>

                            <td>
                                <strong><?= e($row['nomor_peserta']) ?></strong>
                            </td>

                            <td>
                                <strong><?= e($row['nama']) ?></strong>
                            </td>

                            <td>

                                <?php if ($row['kategori'] === 'Kakang'): ?>

                                    <span class="badge badge-kakang px-3 py-2">
                                        Kakang
                                    </span>

                                <?php else: ?>

                                    <span class="badge badge-senduk px-3 py-2">
                                        Senduk
                                    </span>

                                <?php endif; ?>

                            </td>

                            <td><?= e($row['asal_instansi'] ?? '-') ?></td>

                            <td>
                                <strong><?= number_format($row['jumlah_suara']) ?></strong>
                            </td>

                            <td>

                                <div class="d-flex gap-2">

                                    <a href="kontestan.php?edit=<?= (int)$row['id'] ?>"
                                       class="action-btn edit-btn"
                                       title="Edit">

                                        <i class="bi bi-pencil-fill"></i>

                                    </a>


                                    <form method="POST"
                                          onsubmit="return confirm('Yakin ingin menghapus kontestan ini?')">

                                        <input type="hidden"
                                               name="csrf_token"
                                               value="<?= e($_SESSION['csrf_token']) ?>">

                                        <input type="hidden"
                                               name="aksi"
                                               value="hapus">

                                        <input type="hidden"
                                               name="id"
                                               value="<?= (int)$row['id'] ?>">

                                        <button type="submit"
                                                class="action-btn delete-btn"
                                                title="Hapus">

                                            <i class="bi bi-trash-fill"></i>

                                        </button>

                                    </form>

                                </div>

                            </td>

                        </tr>

                    <?php endwhile; ?>

                <?php else: ?>

                    <tr>

                        <td colspan="8" class="text-center py-5 text-muted">

                            <i class="bi bi-inbox fs-1 d-block mb-2"></i>

                            Data kontestan belum tersedia.

                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>


    <div class="text-center text-muted small py-4">

        © <?= date('Y') ?> Pemilihan Kakang Senduk Ponorogo.

    </div>

</main>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
