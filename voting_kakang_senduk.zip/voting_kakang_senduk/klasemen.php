
<?php
require_once __DIR__ . '/pages/_common.php';
$isAdmin = isset($_SESSION['id'], $_SESSION['role']) && $_SESSION['role'] === 'admin';

function e($value) {
    return h($value);
}

// Ambil hasil klasemen berdasarkan kategori dan jumlah suara
$query = $conn->query("
    SELECT
        k.id,
        k.nomor_peserta,
        k.nama,
        k.kategori,
        k.foto,
        COUNT(v.id) AS jumlah_suara
    FROM kontestan k
    LEFT JOIN voting v ON k.id = v.kontestan_id
    GROUP BY
        k.id,
        k.nomor_peserta,
        k.nama,
        k.kategori,
        k.foto
    ORDER BY
        k.kategori ASC,
        jumlah_suara DESC,
        k.nama ASC
");

$kakang = [];
$senduk = [];

while ($row = $query->fetch_assoc()) {
    if ($row['kategori'] === 'Kakang') {
        $kakang[] = $row;
    } else {
        $senduk[] = $row;
    }
}

function tampilkanKlasemen($data, $kategori) {
    ?>
    <div class="mb-5">
        <h3 class="mb-3">Klasemen <?= e($kategori) ?></h3>

        <?php if (count($data) > 0): ?>
            <div class="row g-4">
                <?php foreach ($data as $i => $peserta): ?>
                    <?php
                    $foto = basename(trim($peserta['foto'] ?? ''));
                    $fotoDiAssets = $foto !== '' && is_file(__DIR__ . '/assets/img/kontestan/' . $foto);
                    $fotoDiUploads = $foto !== '' && is_file(__DIR__ . '/uploads/' . $foto);
                    $fotoValid = $fotoDiAssets || $fotoDiUploads;
                    ?>

                    <div class="col-12 col-sm-6 col-lg-4">
                        <div class="card h-100 shadow-sm border-0">
                            <?php if ($fotoValid): ?>
                                <img
                                    src="<?= $fotoDiAssets ? 'assets/img/kontestan/' : 'uploads/' ?><?= rawurlencode($foto) ?>"
                                    class="card-img-top"
                                    alt="Foto <?= e($peserta['nama']) ?>"
                                    style="height:280px; object-fit:cover;"
                                >
                            <?php else: ?>
                                <div class="bg-secondary-subtle d-flex align-items-center justify-content-center"
                                     style="height:280px;">
                                    <span class="text-muted">Foto belum tersedia</span>
                                </div>
                            <?php endif; ?>

                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-center mb-2">
                                    <span class="badge bg-primary">
                                        <?= e($kategori) ?>
                                    </span>

                                    <span class="badge bg-warning text-dark">
                                        Peringkat <?= $i + 1 ?>
                                    </span>
                                </div>

                                <h5 class="card-title">
                                    <?= e($peserta['nama']) ?>
                                </h5>

                                <p class="text-muted mb-2">
                                    Nomor Peserta:
                                    <?= e($peserta['nomor_peserta']) ?>
                                </p>

                                <div class="border-top pt-3">
                                    <span class="text-muted">Perolehan Suara</span>
                                    <h3 class="text-primary mb-0">
                                        <?= (int) $peserta['jumlah_suara'] ?>
                                        <small class="fs-6 text-muted">suara</small>
                                    </h3>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php else: ?>
            <div class="alert alert-info">
                Belum ada kontestan <?= e($kategori) ?>.
            </div>
        <?php endif; ?>
    </div>
    <?php
}
?>

<?php if ($isAdmin): ?>
    <!DOCTYPE html>
    <html lang="id">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Klasemen Kakang Senduk</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
    <?php $sidebarPrefix = 'admin/'; $sitePrefix = ''; include __DIR__ . '/admin/sidebar.php'; ?>
    <main class="main-content py-5">
<?php else: ?>
    <?php renderHeader('Klasemen', 'klasemen', true); ?>
    <main class="container py-5">
<?php endif; ?>

    <div class="text-center mb-5">
        <h2>Klasemen Voting</h2>
        <p class="text-muted">
            Perolehan suara kontestan Pemilihan Kakang Senduk Ponorogo
        </p>
    </div>

    <?php tampilkanKlasemen($kakang, 'Kakang'); ?>

    <?php tampilkanKlasemen($senduk, 'Senduk'); ?>

</main>
<?php renderFooter(); ?>

