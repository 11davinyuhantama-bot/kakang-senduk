
<?php
session_start();
require_once 'config/koneksi.php';

$total = mysqli_query($conn,
    "SELECT COUNT(*) AS jumlah FROM kontestan");
$data_total = mysqli_fetch_assoc($total);

$kakang = mysqli_query($conn,
    "SELECT COUNT(*) AS jumlah FROM kontestan
     WHERE kategori='Kakang'");
$data_kakang = mysqli_fetch_assoc($kakang);

$senduk = mysqli_query($conn,
    "SELECT COUNT(*) AS jumlah FROM kontestan
     WHERE kategori='Senduk'");
$data_senduk = mysqli_fetch_assoc($senduk);
?>

<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport"
content="width=device-width, initial-scale=1">

<title>Kakang Senduk Ponorogo</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
rel="stylesheet">

<link rel="stylesheet" href="assets/css/style.css">
<style>
.hero {
    min-height: calc(100vh - 76px);
    background:
        linear-gradient(rgba(25, 10, 12, .62), rgba(25, 10, 12, .72)),
        url('assets/img/bg-beranda.jpg') center center / cover no-repeat;
}
</style>
</head>

<body>

<nav class="navbar navbar-expand-lg navbar-dark">
<div class="container">

<a class="navbar-brand fw-bold" href="index.php">
KAKANG SENDUK
</a>

<button class="navbar-toggler" type="button"
data-bs-toggle="collapse" data-bs-target="#menu">
<span class="navbar-toggler-icon"></span>
</button>

<div class="collapse navbar-collapse" id="menu">

<ul class="navbar-nav ms-auto align-items-lg-center">

<li class="nav-item">
<a class="nav-link" href="index.php">Beranda</a>
</li>

<li class="nav-item">
<a class="nav-link" href="pages/kontestan.php">
Kontestan
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="klasemen.php">
Klasemen
</a>
</li>

<li class="nav-item">
<a class="nav-link" href="pages/hasil.php">Informasi Hasil</a>
</li>

<?php if (isset($_SESSION['id'])): ?>

<li class="nav-item">
<span class="nav-link">
Halo, <?= htmlspecialchars($_SESSION['nama'], ENT_QUOTES, 'UTF-8') ?>
</span>
</li>

<?php if (($_SESSION['role'] ?? '') === 'pemilih'): ?>
<li class="nav-item"><a class="btn btn-warning ms-lg-2" href="pages/voting.php">Voting</a></li>
<?php endif; ?>

<li class="nav-item">
<a class="btn btn-warning ms-lg-2"
href="auth/logout.php">
Logout
</a>
</li>

<?php else: ?>

<li class="nav-item">
<a class="btn btn-outline-light ms-lg-2"
href="auth/login.php">
Login
</a>
</li>

<li class="nav-item">
<a class="btn btn-warning ms-lg-2"
href="auth/register.php">
Register
</a>
</li>

<?php endif; ?>

</ul>
</div>
</div>
</nav>


<section class="hero">
<div class="container text-center">

<p class="subtitle">
PEMILIHAN DUTA WISATA DAERAH
</p>

<h1>KAKANG SENDUK<br>PONOROGO</h1>

<p class="lead">
Wujudkan generasi muda yang berbudaya,
berprestasi, dan mempromosikan pariwisata
Kabupaten Ponorogo.
</p>

<div class="mt-4">
<a href="pages/kontestan.php"
class="btn btn-warning btn-lg">
Lihat Kontestan
</a>

<a href="pages/voting.php"
class="btn btn-outline-light btn-lg ms-2">
<?= isset($_SESSION['id']) && ($_SESSION['role'] ?? '') === 'pemilih' ? 'Voting Sekarang' : 'Voting / Masuk' ?>
</a>
</div>

</div>
</section>

<section class="container py-5">

<h2 class="text-center fw-bold mb-4">
Statistik Kontestan
</h2>

<div class="row text-center g-3">

<div class="col-md-4">
<div class="stat-card">
<h2><?= $data_total['jumlah']; ?></h2>
<p>Total Kontestan</p>
</div>
</div>

<div class="col-md-4">
<div class="stat-card">
<h2><?= $data_kakang['jumlah']; ?></h2>
<p>Kontestan Kakang</p>
</div>
</div>

<div class="col-md-4">
<div class="stat-card">
<h2><?= $data_senduk['jumlah']; ?></h2>
<p>Kontestan Senduk</p>
</div>
</div>

</div>
</section>

<footer class="text-center py-4">
© 2026 Pemilihan Kakang Senduk Ponorogo
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
